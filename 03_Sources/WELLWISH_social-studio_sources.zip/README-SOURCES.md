# WELLWISH — Social Media Studio (sources éditables)

Tout est généré par code à partir de données : modifier un texte = modifier `src/contents.mjs`, puis relancer le rendu.

## Arborescence
- `src/ds.css` — design system (couleurs, typo, grille, composants, mockups).
- `src/motion.css` — système d'animation (courbes, keyframes).
- `src/tpl.mjs` — gabarits : `cover`, `point`, `statement`, `list`, `vs`, `visual`, `cta` + mockups (navigateur, dashboard, smartphone, flux, chat, outils, entonnoir, planche de marque, boucle).
- `src/contents.mjs` — les 30 contenus (textes IG `ig` / LinkedIn `li`, légendes, CTA, hashtags, dates).
- `src/videos.mjs` — les 10 vidéos, scène par scène (durée, animation, notes de storyboard, voix off, son).
- `scripts/render-slides.mjs` — PNG 1080×1350 Instagram + LinkedIn, PDF document LinkedIn.
- `scripts/render-video.mjs` — MP4 30 i/s (Reel 1080×1920, LinkedIn 1080×1350) + couverture.
- `scripts/build-gallery.mjs` + `scripts/gallery.html` — galerie de prévisualisation.
- `assets/` — polices et logos officiels du Brand & Sales Kit.

## Prérequis
Node 20+, Google Chrome, ffmpeg, `npm i playwright`.

## Commandes
```bash
node scripts/render-slides.mjs                 # tous les carrousels et statiques
node scripts/render-slides.mjs WW-03,WW-06     # seulement certains contenus
node scripts/render-video.mjs P01:ig:v916 P01:li:v45   # une vidéo, deux formats
FPS=10 node scripts/render-video.mjs S01:ig:v916        # aperçu rapide
node scripts/build-gallery.mjs
```
Le chemin de Chrome est `/usr/bin/google-chrome` : sur Mac, remplacer par
`/Applications/Google Chrome.app/Contents/MacOS/Google Chrome` dans les deux scripts de rendu.

## Convention de nommage des dossiers livrés
`AAAA-MM-JJ_WW-NN_Titre` — la date de publication en tête, pour que les
dossiers se classent d'eux-mêmes dans l'ordre de parution. Elle est produite
par `slug()` dans `scripts/package.mjs` ; ne pas la retirer, sinon un nouveau
rendu recrée les anciens dossiers à côté des nouveaux.

`scripts/package-un.mjs WW-31` assemble UN SEUL contenu. `package.mjs` efface
et reconstruit toute la livraison : à ne pas lancer pour un simple ajout.

## Créer un nouveau contenu
Copier une entrée de `contents.mjs`, changer `id`, textes et `slides`. Un mot entre `*astérisques*` passe en dégradé (un seul par titre). Un champ peut être une chaîne (identique sur les deux réseaux) ou `{ ig: '…tu…', li: '…vous…' }`. Toute interface fictive : ajouter `concept: true`.
