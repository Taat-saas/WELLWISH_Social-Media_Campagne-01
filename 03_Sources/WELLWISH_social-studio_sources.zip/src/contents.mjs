// WELLWISH — Campagne 01 · 30 contenus (15 carrousels · 10 vidéos · 5 statiques)
// Règles : aucun prix, aucun chiffre de performance, aucun client inventé.
// Démonstrations = « Exemple illustratif ». IG = tutoiement · LinkedIn = vouvoiement.

const HT = {
  base: ['#WELLWISH', '#agencedigitale'],
  web: ['#siteinternet', '#webdesign', '#UXUI', '#SEO', '#entrepreneur'],
  ecom: ['#ecommerce', '#shopify', '#marketplace', '#ecommercant', '#conversion'],
  saas: ['#SaaS', '#intelligenceartificielle', '#IA', '#automatisation', '#nocode'],
  ads: ['#googleads', '#metaads', '#publicitedigitale', '#acquisition', '#ROAS'],
  brand: ['#branding', '#identitevisuelle', '#logo', '#directionartistique', '#marque'],
  pb: ['#TPE', '#PME', '#dirigeant', '#croissance', '#digitalisation'],
  id: ['#agenceweb', '#marketingdigital', '#transformationdigitale', '#entrepreneuriat'],
};
const LT = {
  web: ['#SiteInternet', '#ExpérienceUtilisateur', '#Conversion'],
  ecom: ['#Ecommerce', '#Marketplaces', '#Conversion'],
  saas: ['#SaaS', '#IntelligenceArtificielle', '#Automatisation'],
  ads: ['#Acquisition', '#MarketingDigital', '#Performance'],
  brand: ['#Branding', '#Marque', '#Positionnement'],
  pb: ['#PME', '#Digitalisation', '#Performance'],
  id: ['#TransformationDigitale', '#Agence', '#Stratégie'],
};
const tags = (k, extra = []) => ({ ig: [...HT.base, ...HT[k], ...extra].join(' '), li: [...LT[k], '#WELLWISH'].join(' ') });

const AUD = {
  ig: 'Entrepreneurs, e-commerçants, créateurs de marques, indépendants, dirigeants de TPE',
  li: 'Dirigeants, responsables marketing / e-commerce / digital, DSI, décideurs PME',
};

export const CONTENTS = [
/* =============================== SEMAINE 1 =============================== */
{ id: 'WW-01', key: 'P01', theme: 'Présentation de WELLWISH', pillar: 'Identité, mission, valeurs', format: 'Vidéo',
  title: 'Manifeste — De l’idée à la performance',
  objective: 'Notoriété : poser l’identité WELLWISH dès le premier contenu',
  hook: { ig: 'De l’idée à la solution. De la solution à la performance.', li: 'De l’idée à la solution. De la solution à la performance.' },
  da: 'Navy profond, grille technique, typographie Bricolage XXL révélée mot à mot. Les 6 expertises défilent en ruban, le symbole W se construit bande par bande en clôture.',
  cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' },
  captionIG: `De l’idée à la solution. De la solution à la performance. ⚡️

WELLWISH, c’est une agence digitale, webmarketing et technologique.
On ne vend pas « un site » ou « une campagne ». On construit ce qui fait avancer ton activité :

→ sites et e-commerce
→ logiciels SaaS, web apps et IA
→ publicité et acquisition
→ branding et communication

Une seule équipe, de la réflexion au déploiement.

Tu as une idée, un projet, un blocage ? Parlons-en 👇
Lien en bio · wellwish.fr`,
  textLI: `De l’idée à la solution. De la solution à la performance.

C’est la manière la plus simple de résumer ce que fait WELLWISH.

Nous accompagnons les entrepreneurs, les TPE, les PME et les marques dans leur développement digital, à la croisée de quatre univers :
• le web et l’e-commerce,
• le logiciel, l’automatisation et l’intelligence artificielle,
• l’acquisition et la publicité,
• la marque et la communication.

Notre conviction : un projet digital ne se juge pas à sa livraison, mais à ce qu’il change dans l’activité — du temps gagné, des opportunités générées, des opérations mieux pilotées.

C’est pourquoi nous intervenons de la réflexion jusqu’au déploiement, avec un seul interlocuteur capable de comprendre les dimensions techniques, marketing et économiques d’un même projet.

Dans les prochaines semaines, nous partagerons ici notre méthode, nos convictions et des cas concrets.

Un projet en tête ? Parlons-en : wellwish.fr/contact`,
  tags: tags('id'), video: 'P01' },

{ id: 'WW-02', key: 'P03', theme: 'Présentation de WELLWISH', pillar: 'Présentation des offres', format: 'Statique',
  title: 'Plus qu’une agence web : un partenaire de développement',
  objective: 'Positionnement : se distinguer des agences de création de sites',
  hook: { ig: 'On ne fait pas « juste » des sites.', li: 'WELLWISH n’est pas une agence de création de sites internet.' },
  da: 'Statique navy, phrase-manifeste en Bricolage XL, mot-clé en dégradé, 4 étiquettes mono des univers. Symbole W franchement recadré en bas à droite.',
  static: { l: 'statement', bg: 'navy', deco: 'w', kicker: 'WELLWISH',
    title: { ig: 'Pas une agence web.\nTon *partenaire* de développement digital.', li: 'Pas une agence web.\nVotre *partenaire* de développement digital.' },
    body: 'Web · E-commerce · SaaS & IA · Acquisition · Branding' },
  cta: { ig: 'Découvre comment on peut t’accompagner', li: 'Découvrez comment WELLWISH peut vous accompagner' },
  captionIG: `On ne fait pas « juste » des sites. 🙅‍♂️

Un site, une boutique, un logiciel ou une campagne ne sont pas des fins en soi. Ce sont des outils au service d’un objectif : vendre plus, gagner du temps, mieux piloter.

Chez WELLWISH, on part toujours de là :
1. ton activité et tes enjeux
2. la solution qui y répond vraiment
3. le déploiement… et ce qui vient après

Tech + marketing + e-commerce, dans la même équipe.

👉 Découvre comment on peut t’accompagner : lien en bio`,
  textLI: `WELLWISH n’est pas une agence de création de sites internet.

Le site, la boutique en ligne, l’application métier ou la campagne publicitaire ne sont que des moyens. Ce qui compte, ce sont les enjeux qu’ils servent : commerciaux, opérationnels, économiques.

C’est la raison pour laquelle nous réunissons dans une même équipe :
→ une expertise technologique (web, SaaS, automatisation, IA),
→ une expertise marketing (acquisition, contenus, marque),
→ une compréhension concrète du e-commerce et des marketplaces.

Résultat : un interlocuteur unique, capable de raisonner sur l’ensemble d’un projet digital plutôt que sur une seule brique.

Découvrez comment WELLWISH peut vous accompagner : wellwish.fr`,
  tags: tags('id') },

{ id: 'WW-03', key: 'W01', theme: 'Développement web', pillar: 'Problématiques clients & solutions', format: 'Carrousel',
  title: 'Votre site travaille-t-il réellement pour votre entreprise ?',
  objective: 'Éducation + génération de leads (audit / refonte de site)',
  hook: { ig: 'Ton site travaille-t-il vraiment pour toi ?', li: 'Votre site internet travaille-t-il réellement pour votre entreprise ?' },
  da: 'Couverture lavande + orbe dégradé. Slides intérieures blanc chaud, numérotation entre crochets, mockup navigateur avant/après marqué « exemple illustratif ». CTA navy.',
  slides: [
    { l: 'cover', kicker: 'Web · Diagnostic', title: { ig: 'Ton site *travaille* pour toi, ou l’inverse ?', li: 'Votre site *travaille* pour vous, ou l’inverse ?' }, sub: { ig: '5 signaux à vérifier en 5 minutes.', li: '5 signaux à vérifier en 5 minutes.' } },
    { l: 'statement', kicker: 'Le problème', title: 'Un site en ligne n’est pas un site *utile*.', body: { ig: 'Beaucoup de sites existent… sans jamais générer une demande, un appel ou une vente.', li: 'Beaucoup de sites existent sans jamais générer de demande, d’appel ou de vente.' } },
    { l: 'point', num: '01', title: 'La promesse se comprend en 5 secondes.', body: { ig: 'Ce que tu fais, pour qui, et la prochaine étape : visibles sans défiler.', li: 'Ce que vous faites, pour qui, et la prochaine étape : visibles sans défiler.' } },
    { l: 'point', num: '02', title: 'Chaque page mène à une action.', body: 'Demander un devis, réserver, appeler, acheter. Une page sans appel à l’action est une impasse.' },
    { l: 'point', num: '03', title: 'Il est rapide, surtout sur mobile.', body: 'La majorité des visites se font sur smartphone. Un site lent perd ses visiteurs avant même de les convaincre.' },
    { l: 'list', kicker: 'Et aussi', title: 'Les deux signaux qu’on oublie.', items: [ { t: 'Il est trouvable', s: 'Référencement naturel, fiche Google, pages pensées pour les recherches réelles.' }, { t: 'Il est mesuré', s: 'Sans suivi des demandes et des ventes, impossible de savoir ce qui marche.' } ] },
    { l: 'vs', kicker: 'Avant / Après', title: 'Même trafic. Autre *résultat*.', concept: true, bad: { h: 'Site vitrine figé', r: ['Promesse floue', 'Aucun appel à l’action', 'Lent sur mobile', 'Aucune mesure'] }, good: { h: 'Site qui travaille', r: ['Promesse en une phrase', 'Un parcours vers le contact', 'Rapide partout', 'Demandes suivies'] } },
    { l: 'cta', title: { ig: 'Faisons de ton site un *levier*.', li: 'Faisons de votre site un *levier*.' }, body: { ig: 'Refonte, optimisation UX, SEO : on part de tes objectifs.', li: 'Refonte, optimisation UX, SEO : nous partons de vos objectifs.' }, cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' } },
  ],
  cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' },
  captionIG: `Ton site travaille-t-il vraiment pour toi ? 🤔

Un site en ligne n’est pas forcément un site utile. Fais le test avec ces 5 signaux :

01 — Ta promesse se comprend en 5 secondes
02 — Chaque page mène à une action
03 — Il est rapide sur mobile
04 — Il est trouvable sur Google
05 — Tu mesures les demandes qu’il génère

Moins de 3 sur 5 ? Ton site te coûte plus qu’il ne te rapporte.

💾 Enregistre ce post pour faire le check
💬 Écris « AUDIT » en commentaire si tu veux qu’on en parle`,
  textLI: `Votre site internet travaille-t-il réellement pour votre entreprise ?

Beaucoup d’entreprises disposent d’un site « en ligne », sans qu’il ne génère jamais de demande, d’appel ou de vente. Il existe, mais il ne travaille pas.

Cinq signaux permettent de faire un premier diagnostic :

1. La promesse est comprise en quelques secondes : ce que vous faites, pour qui, et la prochaine étape.
2. Chaque page conduit à une action : devis, réservation, appel, achat.
3. Le site est rapide, en particulier sur mobile.
4. Il est trouvable : référencement naturel, fiche Google, contenus alignés sur les recherches réelles.
5. Il est mesuré : vous savez combien de demandes il génère, et d’où elles viennent.

Si votre site ne coche pas au moins trois de ces critères, il représente probablement un coût plutôt qu’un investissement.

Le carrousel ci-dessous détaille chaque point. Et si vous souhaitez un regard extérieur sur votre site, échangeons : wellwish.fr/contact`,
  tags: tags('web') },

/* =============================== SEMAINE 2 =============================== */
{ id: 'WW-04', key: 'P02', theme: 'Présentation de WELLWISH', pillar: 'Présentation des offres', format: 'Carrousel',
  title: 'WELLWISH en 6 expertises',
  objective: 'Faire connaître l’ensemble des offres et leur logique',
  hook: { ig: 'Tout ce qu’on peut construire pour ton activité.', li: 'Six expertises, une seule logique : votre croissance.' },
  da: 'Une slide par famille d’offres avec icône en tuile lavande, titre court, 3 bénéfices. Rythme blanc / navy alterné, CTA navy.',
  slides: [
    { l: 'cover', kicker: 'WELLWISH · Expertises', big: '6', title: { ig: 'expertises pour faire *grandir* ton activité.', li: 'expertises pour faire *grandir* votre activité.' }, size: 'd-lg' },
    { l: 'list', kicker: '01 · Web', title: 'Sites vitrines, e-commerce, réservation et paiement.', size: 'd-sm', items: [ { t: 'Création et refonte' }, { t: 'UX/UI et référencement naturel' }, { t: 'Maintenance et évolution' } ] },
    { l: 'list', kicker: '02 · E-commerce & marketplaces', title: 'Une boutique qui vend, des canaux qui se complètent.', size: 'd-sm', items: [ { t: 'Shopify et autres CMS' }, { t: 'Fiches produits et catalogues' }, { t: 'Flux e-commerce automatisés' } ] },
    { l: 'list', bg: 'navy', kicker: '03 · SaaS & IA', title: { ig: 'Des logiciels qui s’adaptent à ton métier.', li: 'Des logiciels qui s’adaptent à votre métier.' }, size: 'd-sm', items: [ { t: 'SaaS et web apps sur mesure' }, { t: 'Assistants IA et automatisation' }, { t: 'Données et processus centralisés' } ] },
    { l: 'list', kicker: '04 · Acquisition', title: 'Des campagnes pilotées par la rentabilité.', size: 'd-sm', items: [ { t: 'Google, Meta, Instagram, Amazon Ads' }, { t: 'Contenus publicitaires et retargeting' }, { t: 'Analyse et optimisation du ROAS' } ] },
    { l: 'list', kicker: '05 · Branding', title: 'Une marque reconnaissable, cohérente partout.', size: 'd-sm', items: [ { t: 'Identité visuelle et logo' }, { t: 'Positionnement et storytelling' }, { t: 'Accompagnement au lancement' } ] },
    { l: 'list', kicker: '06 · Communication digitale', title: 'Une présence régulière, pas par à-coups.', size: 'd-sm', items: [ { t: 'Réseaux sociaux et contenus' }, { t: 'Stratégie éditoriale et SEO' }, { t: 'Email marketing' } ] },
    { l: 'cta', title: 'Un projet ? Une seule *équipe*.', body: { ig: 'Tu n’as pas à coordonner cinq prestataires.', li: 'Vous n’avez pas à coordonner cinq prestataires.' }, cta: { ig: 'Découvre nos offres', li: 'Découvrez nos offres' } },
  ],
  cta: { ig: 'Découvre nos offres', li: 'Découvrez nos offres' },
  captionIG: `6 expertises, une seule équipe. 🧩

01 Web — sites vitrines, e-commerce, réservation, SEO
02 E-commerce & marketplaces — Shopify, fiches produits, automatisation
03 SaaS & IA — logiciels sur mesure, assistants IA
04 Acquisition — Google, Meta, Instagram, Amazon Ads
05 Branding — identité, logo, positionnement
06 Communication — réseaux sociaux, contenus, email

L’idée : tu n’as plus à coordonner cinq prestataires qui ne se parlent pas.

Swipe pour le détail 👉 et dis-nous en commentaire laquelle t’intéresse le plus.`,
  textLI: `Six expertises, une seule logique : votre croissance.

WELLWISH réunit dans une même équipe les compétences qu’un projet digital mobilise réellement :

1. Développement web — sites vitrines, e-commerce, réservation et paiement en ligne, UX/UI, SEO, maintenance.
2. E-commerce & marketplaces — Shopify et autres CMS, fiches produits, catalogues, automatisation des flux.
3. SaaS & intelligence artificielle — logiciels et web apps sur mesure, assistants IA, centralisation des données.
4. Acquisition — Google Ads, Meta Ads, Instagram Ads, Amazon Ads, retargeting, pilotage du ROAS.
5. Branding — identité visuelle, positionnement, storytelling, accompagnement au lancement.
6. Communication digitale — réseaux sociaux, stratégie éditoriale, SEO, email marketing.

Pourquoi les réunir ? Parce qu’un site, une campagne et un outil métier se répondent. Les traiter séparément, c’est multiplier les interlocuteurs et perdre la cohérence d’ensemble.

Découvrez nos offres : wellwish.fr/offres`,
  tags: tags('id') },

{ id: 'WW-05', key: 'S01', theme: 'SaaS et intelligence artificielle', pillar: 'Intelligence artificielle & innovation', format: 'Vidéo',
  title: 'Et si votre prochain collaborateur était une IA ?',
  objective: 'Susciter l’intérêt pour les assistants IA métier',
  hook: { ig: 'Et si ton prochain collaborateur était une IA ?', li: 'Et si votre prochain collaborateur était une intelligence artificielle ?' },
  da: 'Interface de chat d’assistant IA (concept illustratif) qui répond en temps réel, puis enchaîne des actions : devis préparé, email rédigé, CRM mis à jour. Fond navy, bulles lavande.',
  cta: { ig: 'Construisons ton assistant', li: 'Construisons ensemble votre prochaine solution' },
  captionIG: `Et si ton prochain collaborateur était une IA ? 🤖

Pas un gadget. Un assistant branché sur TES outils, qui :
→ répond aux questions fréquentes
→ prépare un devis à partir d’une demande
→ rédige les emails de relance
→ met à jour ton CRM

Toi, tu valides. Lui, il exécute.

⚠️ La vidéo est un exemple illustratif : chaque assistant se conçoit à partir de tes vrais processus.

On en parle ? Lien en bio.`,
  textLI: `Et si votre prochain collaborateur était une intelligence artificielle ?

La question n’est plus de savoir si l’IA peut être utile à une PME, mais où elle l’est concrètement.

Un assistant IA métier n’est pas un chatbot générique. Il est connecté à vos outils et à vos données, et prend en charge des tâches précises :
• répondre aux questions récurrentes de vos clients ou de vos équipes,
• préparer un devis à partir d’une demande entrante,
• rédiger des relances,
• mettre à jour votre CRM.

L’humain garde la main sur la validation. L’assistant absorbe la partie répétitive.

La vidéo présente un exemple illustratif. Dans la réalité, tout commence par l’analyse de vos processus : quelles tâches prennent du temps, lesquelles peuvent être fiabilisées, et avec quelles données.

Vous identifiez déjà des tâches à confier à une IA ? Échangeons : wellwish.fr/contact`,
  tags: tags('saas'), video: 'S01' },

{ id: 'WW-06', key: 'E01', theme: 'E-commerce et marketplaces', pillar: 'Problématiques clients & solutions', format: 'Carrousel',
  title: 'Le trafic ne fait pas votre chiffre d’affaires. La conversion, oui.',
  objective: 'Éducation conversion e-commerce + leads optimisation boutique',
  hook: { ig: 'Le trafic ne fait pas ton CA. La conversion, oui.', li: 'Le trafic ne fait pas votre chiffre d’affaires. La conversion, oui.' },
  da: 'Entonnoir visuel trafic → fiche produit → panier → commande avec les « fuites » signalées en corail profond. Mockup smartphone de fiche produit (illustratif).',
  slides: [
    { l: 'cover', kicker: 'E-commerce · Conversion', title: 'Le trafic ne fait pas le *chiffre*.', sub: 'La conversion, oui.', deco: 'orb' },
    { l: 'statement', kicker: 'Le problème', title: { ig: 'Ta boutique reçoit des visites… mais pas de *commandes*.', li: 'Votre boutique reçoit des visites… mais pas de *commandes*.' }, size: 'd-md' },
    { l: 'visual', kicker: 'Où ça fuit', title: 'Chaque étape du parcours peut perdre des acheteurs.', v: { type: 'funnel', steps: ['Visite', 'Fiche produit', 'Panier', 'Paiement', 'Commande'], leak: [ 'Message flou', 'Photos, avis', 'Frais surprise', 'Trop d’étapes' ] } },
    { l: 'point', num: '01', title: 'Des fiches produits qui répondent aux objections.', body: 'Photos utiles, bénéfices avant caractéristiques, avis, livraison et retours visibles.' },
    { l: 'point', num: '02', title: 'Un panier sans mauvaise surprise.', body: 'Frais de livraison annoncés tôt, moyens de paiement rassurants, réassurance au bon endroit.' },
    { l: 'visual', num: null, kicker: '03 · Mobile d’abord', title: 'Un tunnel d’achat pensé pour le pouce.', v: { type: 'phone-shop' }, concept: true },
    { l: 'statement', bg: 'lav', deco: null, kicker: 'Le bénéfice', title: 'Plus de ventes, *sans* acheter plus de trafic.', size: 'd-md' },
    { l: 'cta', title: { ig: 'Fais de ta boutique ton meilleur *vendeur*.', li: 'Faites de votre boutique votre meilleur *vendeur*.' }, cta: { ig: 'Parlons de ta boutique', li: 'Parlons de votre boutique' } },
  ],
  cta: { ig: 'Parlons de ta boutique', li: 'Parlons de votre boutique' },
  captionIG: `Le trafic ne fait pas ton CA. La conversion, oui. 🛒

Avant d’augmenter ton budget pub, regarde où tes visiteurs décrochent :
→ un message flou dès l’arrivée
→ des fiches produits qui ne rassurent pas
→ des frais qui apparaissent au dernier moment
→ un paiement trop long sur mobile

Chaque fuite colmatée, c’est du chiffre en plus avec le même trafic.

💾 Enregistre pour ton prochain audit de boutique
👉 On regarde la tienne ensemble ? Lien en bio`,
  textLI: `Le trafic ne fait pas votre chiffre d’affaires. La conversion, oui.

C’est l’un des réflexes les plus coûteux en e-commerce : face à des ventes insuffisantes, augmenter le budget d’acquisition. Or si le parcours d’achat perd ses visiteurs, chaque euro supplémentaire alimente la même fuite.

Les points de rupture les plus fréquents :
• une proposition de valeur peu claire à l’arrivée,
• des fiches produits qui ne lèvent pas les objections (photos, bénéfices, avis, livraison),
• des frais découverts au moment du paiement,
• un tunnel d’achat trop long ou mal adapté au mobile.

Optimiser la conversion, c’est augmenter le chiffre d’affaires généré par le trafic que vous payez déjà. C’est souvent le levier le plus rentable avant tout investissement publicitaire.

Vous souhaitez identifier les fuites de votre boutique ? Parlons-en : wellwish.fr/contact`,
  tags: tags('ecom') },

/* =============================== SEMAINE 3 =============================== */
{ id: 'WW-07', key: 'M01', theme: 'Mission, vision et valeurs', pillar: 'Identité, mission, valeurs', format: 'Statique',
  title: 'Notre mission',
  objective: 'Ancrer la mission et l’identité de marque',
  hook: { ig: 'Ce qu’on fait, en une phrase.', li: 'Notre mission, en une phrase.' },
  da: 'Fond lavande, grande citation de mission, filet dégradé signature, orbe dégradé en coin.',
  static: { l: 'statement', bg: 'lav', deco: 'orb-tl', kicker: 'Notre mission',
    title: 'Transformer les idées en *solutions*, les processus en systèmes, la présence digitale en croissance.', size: 'd-md' },
  cta: { ig: 'Passe de l’idée à l’action', li: 'Passez de l’idée à l’action' },
  captionIG: `Notre mission, en une phrase 👇

Transformer tes idées en solutions concrètes, tes processus en systèmes performants et ta présence digitale en vrai levier de croissance.

Digital, technologie, marketing, IA : tout ça n’a de sens que si ça accélère ton développement.

C’est ce qu’on construit, chaque jour, avec les entrepreneurs qu’on accompagne.

Passe de l’idée à l’action → lien en bio`,
  textLI: `Notre mission tient en une phrase.

Aider les entreprises à exploiter pleinement le potentiel du digital, de la technologie, du marketing et de l’intelligence artificielle pour accélérer leur développement.

Concrètement :
→ transformer des idées en solutions concrètes,
→ transformer des processus en systèmes performants,
→ transformer une présence digitale en véritable levier de croissance.

Chaque projet que nous menons est évalué à cette aune : qu’a-t-il changé, concrètement, dans l’activité de l’entreprise ?

Passez de l’idée à l’action : wellwish.fr`,
  tags: tags('id') },

{ id: 'WW-08', key: 'A01', theme: 'Publicité et acquisition', pillar: 'Problématiques clients & solutions', format: 'Carrousel',
  title: 'Arrêtez de financer des publicités qui ne génèrent aucun résultat',
  objective: 'Leads gestion publicitaire — sensibiliser au pilotage par la rentabilité',
  hook: { ig: 'Arrête de financer des pubs qui ne rapportent rien.', li: 'Arrêtez de financer des publicités qui ne génèrent aucun résultat.' },
  da: 'Ton plus tranché : couverture navy. Liste des 4 erreurs, dashboard (données fictives) en preuve de méthode. CTA navy.',
  slides: [
    { l: 'cover', bg: 'navy', deco: 'grid', kicker: 'Acquisition · Ads', title: { ig: 'Arrête de *financer* des pubs qui ne rapportent rien.', li: 'Arrêtez de *financer* des publicités sans résultat.' } },
    { l: 'statement', bg: 'white', deco: null, kicker: 'Le constat', title: { ig: 'Tu dépenses. Tu ne sais pas *ce que ça rapporte*.', li: 'Le budget part. Le retour reste *inconnu*.' }, size: 'd-md', body: 'C’est le cas le plus fréquent — et le plus coûteux.' },
    { l: 'list', kicker: 'Les 4 causes', title: 'Pourquoi les campagnes ne sont pas rentables.', size: 'd-sm', items: [ { t: 'Aucun suivi des conversions', s: 'Impossible d’optimiser ce qu’on ne mesure pas.' }, { t: 'Une cible trop large', s: 'Le budget se dilue sur des profils qui n’achèteront pas.' }, { t: 'Des visuels interchangeables', s: 'Une pub qui ressemble à toutes les autres ne s’arrête pas dans le fil.' }, { t: 'Une page d’arrivée faible', s: 'Le clic est payé, la vente est perdue.' } ] },
    { l: 'visual', kicker: 'La méthode', title: 'Piloter par la rentabilité, pas par les clics.', v: { type: 'dash', kpis: ['ROAS', 'CPA', 'Conversions'], title: 'Campagnes', h: 560 }, concept: true },
    { l: 'point', num: '→', title: 'Mesurer. Tester. Couper. Renforcer.', body: 'Suivi des conversions, tests créatifs en continu, budget réalloué vers ce qui rapporte, retargeting des visiteurs chauds.' },
    { l: 'statement', bg: 'lav', deco: null, kicker: 'Le bénéfice', title: 'Chaque euro investi a une *raison* d’être là.', size: 'd-md' },
    { l: 'cta', title: { ig: 'On remet tes campagnes à *plat* ?', li: 'Remettons vos campagnes à *plat*.' }, cta: { ig: 'Parlons de tes campagnes', li: 'Contactez-nous' } },
  ],
  cta: { ig: 'Parlons de tes campagnes', li: 'Contactez-nous pour échanger sur vos besoins' },
  captionIG: `Arrête de financer des pubs qui ne rapportent rien. 💸

Si tu ne sais pas combien te rapporte 1 € de pub, ce n’est pas une stratégie, c’est un pari.

Les 4 causes qu’on retrouve le plus :
1. pas de suivi des conversions
2. une cible trop large
3. des visuels qui ressemblent à tout le reste
4. une page d’arrivée qui ne convertit pas

La bonne logique : mesurer → tester → couper → renforcer.

👉 Tu veux qu’on regarde tes campagnes ? Écris « ADS » en DM.`,
  textLI: `Arrêtez de financer des publicités qui ne génèrent aucun résultat.

Dans de nombreuses entreprises, la publicité en ligne est pilotée au ressenti : un budget mensuel, quelques visuels, et l’espoir que « ça finisse par marcher ».

Les causes d’une campagne non rentable sont souvent les mêmes :
1. un suivi des conversions absent ou mal paramétré,
2. un ciblage trop large,
3. des créations publicitaires peu différenciantes,
4. une page d’arrivée qui ne transforme pas le clic payé en vente.

Piloter par la rentabilité implique une discipline simple : mesurer chaque conversion, tester les messages et les visuels en continu, couper ce qui ne performe pas, renforcer ce qui rapporte — et réactiver les visiteurs qui ont déjà montré de l’intérêt.

L’objectif n’est pas de dépenser plus, mais que chaque euro investi ait une raison d’être là.

Contactez-nous pour échanger sur vos campagnes : wellwish.fr/contact`,
  tags: tags('ads') },

{ id: 'WW-09', key: 'B02', theme: 'Branding et identité de marque', pillar: 'Démonstrations & réalisations', format: 'Vidéo',
  title: 'Votre identité digitale parle avant vous',
  objective: 'Démontrer la valeur d’une identité cohérente (concept illustratif)',
  hook: { ig: 'Ton identité digitale parle avant toi.', li: 'Votre identité digitale parle avant vous.' },
  da: 'Construction d’une identité de marque fictive en direct : grille, symbole, palette, typographie, puis déclinaisons (site, post, packaging) qui apparaissent en cascade. Mention « concept illustratif ».',
  cta: { ig: 'Construisons ta marque', li: 'Donnez une nouvelle dimension à votre présence digitale' },
  captionIG: `Ton identité digitale parle avant toi. 👀

Avant le premier appel, ton futur client a déjà vu :
ton logo, ton site, ton Insta, ta fiche Google.

En 3 secondes, il s’est fait une idée : pro ou amateur, premium ou bas de gamme, fiable ou pas.

Une identité cohérente, c’est :
→ un symbole et des couleurs qui se reconnaissent
→ une typo qui a du caractère
→ les mêmes codes partout

(Marque de la vidéo = concept illustratif.)

On construit la tienne ? Lien en bio ✨`,
  textLI: `Votre identité digitale parle avant vous.

Avant tout premier échange, un prospect a souvent déjà consulté votre site, votre page LinkedIn, vos supports. En quelques secondes, il se forme une opinion sur votre sérieux, votre niveau de gamme et votre fiabilité.

Une identité de marque performante n’est pas qu’un logo. C’est un système :
• un symbole et une palette immédiatement reconnaissables,
• une typographie qui porte une personnalité,
• des règles d’usage appliquées de façon cohérente sur tous les points de contact.

La vidéo illustre cette logique sur une marque fictive : du principe graphique aux déclinaisons sur le site, les réseaux et le packaging.

Votre identité reflète-t-elle aujourd’hui votre niveau d’exigence ? Échangeons : wellwish.fr/contact`,
  tags: tags('brand'), video: 'B02' },

/* =============================== SEMAINE 4 =============================== */
{ id: 'WW-10', key: 'M02', theme: 'Mission, vision et valeurs', pillar: 'Identité, mission, valeurs', format: 'Carrousel',
  title: 'Nos 8 valeurs',
  objective: 'Créer de la proximité et de la confiance',
  hook: { ig: '8 valeurs. Zéro bla-bla.', li: 'Huit valeurs qui guident chacun de nos projets.' },
  da: 'Une slide = deux valeurs en grand, chacune avec son engagement concret. Alternance lavande / blanc / navy. Numéros entre crochets.',
  slides: [
    { l: 'cover', kicker: 'WELLWISH · Valeurs', big: '8', title: 'valeurs. Et ce qu’elles changent *concrètement*.', size: 'd-lg' },
    { l: 'list', kicker: 'Valeurs 01 — 02', title: 'Innover, avec exigence.', size: 'd-sm', items: [ { t: 'Innovation', s: 'Exploiter les nouvelles technologies pour créer de meilleures solutions.' }, { t: 'Exigence', s: 'Rechercher la qualité dans chaque réalisation.' } ] },
    { l: 'list', bg: 'navy', kicker: 'Valeurs 03 — 04', title: 'Des résultats, en toute clarté.', size: 'd-sm', items: [ { t: 'Performance', s: 'Concevoir des solutions orientées résultats.' }, { t: 'Transparence', s: 'Construire une relation de confiance avec nos clients.' } ] },
    { l: 'list', kicker: 'Valeurs 05 — 06', title: 'Créer, et s’impliquer.', size: 'd-sm', items: [ { t: 'Créativité', s: 'Proposer des expériences digitales différenciantes.' }, { t: 'Engagement', s: 'Nous impliquer dans la réussite des projets.' } ] },
    { l: 'list', bg: 'lav', kicker: 'Valeurs 07 — 08', title: 'Simple, et sur mesure.', size: 'd-sm', items: [ { t: 'Simplicité', s: 'Rendre accessibles des problématiques technologiques complexes.' }, { t: 'Adaptabilité', s: 'Construire des solutions adaptées aux besoins réels de chaque entreprise.' } ] },
    { l: 'statement', kicker: 'Notre vision', title: 'Le digital comme accélérateur, *quelle que soit* la taille de l’entreprise.', size: 'd-md' },
    { l: 'cta', title: { ig: 'Construisons *ensemble*.', li: 'Construisons *ensemble*.' }, cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' } },
  ],
  cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' },
  captionIG: `8 valeurs. Zéro bla-bla. 🤝

Innovation · Exigence · Performance · Transparence
Créativité · Engagement · Simplicité · Adaptabilité

Des mots qu’on lit partout ? Peut-être. Alors voilà ce qu’ils veulent dire chez nous :
→ on t’explique simplement ce qui est technique
→ on te dit ce qui marche… et ce qui ne marche pas
→ on construit pour TON activité, pas un modèle tout fait

Laquelle compte le plus pour toi quand tu choisis un prestataire ? 👇`,
  textLI: `Huit valeurs guident chacun de nos projets.

Innovation — exploiter les nouvelles technologies pour créer de meilleures solutions.
Exigence — rechercher la qualité dans chaque réalisation.
Performance — concevoir des solutions orientées résultats.
Transparence — construire une relation de confiance avec nos clients.
Créativité — proposer des expériences digitales différenciantes.
Engagement — nous impliquer dans la réussite des projets.
Simplicité — rendre accessibles des problématiques technologiques complexes.
Adaptabilité — construire des solutions adaptées aux besoins réels de chaque entreprise.

Ces valeurs servent une vision : faire du digital un accélérateur de croissance accessible à toutes les entreprises, indépendamment de leur taille ou de leur maturité technologique.

Laquelle est, selon vous, la plus déterminante dans le choix d’un partenaire digital ?`,
  tags: tags('id') },

{ id: 'WW-11', key: 'C01', theme: 'Problématiques clients', pillar: 'Intelligence artificielle & innovation', format: 'Carrousel',
  title: 'Votre entreprise perd-elle du temps sur des tâches automatisables ?',
  objective: 'Leads automatisation / IA',
  hook: { ig: 'Combien de temps tu perds sur des tâches qu’un outil ferait seul ?', li: 'Votre entreprise perd-elle du temps sur des tâches qui pourraient être automatisées ?' },
  da: 'Structure Problème → Conséquences → Diagnostic → Solution → Bénéfices → CTA. Schéma de flux automatisé (illustratif) en nœuds reliés.',
  slides: [
    { l: 'cover', kicker: 'Automatisation · IA', title: { ig: 'Tes équipes font le travail d’un *logiciel* ?', li: 'Vos équipes font-elles le travail d’un *logiciel* ?' } },
    { l: 'list', kicker: 'Le problème', title: 'Les tâches qui reviennent chaque semaine.', size: 'd-sm', items: [ { t: 'Ressaisir les mêmes données' }, { t: 'Copier-coller entre outils' }, { t: 'Relancer à la main' }, { t: 'Compiler des tableaux de suivi' } ] },
    { l: 'statement', kicker: 'Les conséquences', title: 'Du temps perdu, des *erreurs*, des équipes frustrées.', size: 'd-md', body: 'Et une croissance freinée : plus d’activité = plus de tâches manuelles.' },
    { l: 'point', num: '?', title: 'Le diagnostic en 3 questions.', body: 'Est-ce répétitif ? Est-ce basé sur des règles ? Les données existent-elles déjà quelque part ? Trois « oui » : c’est automatisable.' },
    { l: 'visual', kicker: 'La solution', title: 'Un flux qui tourne tout seul.', v: { type: 'flow', nodes: [ { i: 'mail', t: 'Nouvelle demande reçue' }, { i: 'db', t: 'Fiche client créée', auto: true }, { i: 'doc', t: 'Devis pré-rempli', auto: true }, { i: 'bolt', t: 'Relance programmée', auto: true } ] }, concept: true },
    { l: 'statement', bg: 'lav', deco: null, kicker: 'Les bénéfices', title: 'Moins de saisie. Plus de *décisions*.', size: 'd-md', body: 'Des données fiables, des équipes recentrées sur la valeur, une croissance sans surcharge.' },
    { l: 'cta', title: { ig: 'Passe de l’idée à l’*action*.', li: 'Passez de l’idée à l’*action*.' }, body: { ig: 'Liste-nous tes tâches répétitives, on te dit ce qui s’automatise.', li: 'Listez vos tâches répétitives : nous identifions ce qui s’automatise.' }, cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' } },
  ],
  cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' },
  captionIG: `Combien d’heures par semaine tu perds sur des tâches qu’un outil ferait seul ? ⏱️

Ressaisir des données. Copier-coller entre 3 logiciels. Relancer à la main. Compiler des tableaux.

Le test rapide :
✔︎ c’est répétitif ?
✔︎ ça suit des règles ?
✔︎ les données existent déjà ?

3 oui = c’est automatisable (et parfois avec de l’IA).

👉 Envoie-nous ta liste de tâches qui te saoulent, on te dit ce qui peut tourner tout seul.`,
  textLI: `Votre entreprise perd-elle du temps sur des tâches qui pourraient être automatisées ?

Ressaisie de données, copier-coller entre outils, relances manuelles, consolidation de tableaux de suivi… Ces tâches semblent anodines individuellement. Cumulées, elles mobilisent un temps considérable et génèrent des erreurs.

Leur coût le plus important est souvent invisible : elles grandissent avec l’activité. Plus de clients signifie plus de tâches manuelles, et donc une croissance qui se paie en surcharge.

Trois questions suffisent pour un premier diagnostic :
1. La tâche est-elle répétitive ?
2. Repose-t-elle sur des règles identifiables ?
3. Les données nécessaires existent-elles déjà dans vos outils ?

Si la réponse est trois fois oui, la tâche est automatisable — et l’IA permet désormais de traiter aussi des cas moins structurés (emails, documents, demandes entrantes).

Listez vos tâches répétitives : nous vous aidons à identifier celles qui peuvent être confiées à un système. wellwish.fr/contact`,
  tags: tags('saas', ['#productivite']) },

{ id: 'WW-12', key: 'W02', theme: 'Développement web', pillar: 'Démonstrations & réalisations', format: 'Vidéo',
  title: 'Un beau site qui ne convertit pas reste un mauvais investissement',
  objective: 'Démontrer la différence entre un site « joli » et un site performant',
  hook: { ig: 'Un beau site qui ne convertit pas, c’est un mauvais investissement.', li: 'Un beau site internet qui ne convertit pas reste un mauvais investissement.' },
  da: 'Avant/après animé : un site vieillissant désaturé se transforme en site moderne (concept illustratif). Annotations qui pointent promesse, CTA, réassurance, vitesse.',
  cta: { ig: 'Parlons de ton site', li: 'Parlons de votre projet' },
  captionIG: `Un beau site qui ne convertit pas, c’est un mauvais investissement. 🎯

Le design compte. Mais un site, c’est d’abord un outil commercial :
→ une promesse claire dès l’arrivée
→ un appel à l’action visible
→ de la réassurance (avis, paiement, contact)
→ de la vitesse, surtout sur mobile

Beau ET efficace : c’est possible, c’est même le minimum.

(Avant/après = exemple illustratif.)

👉 Ton site mérite un vrai diagnostic ? Lien en bio.`,
  textLI: `Un beau site internet qui ne convertit pas reste un mauvais investissement.

Le design est un levier de crédibilité. Mais un site d’entreprise est avant tout un outil commercial, et il se juge à ce qu’il produit : des demandes, des réservations, des ventes.

Les éléments qui font la différence sont rarement esthétiques :
• une proposition de valeur comprise dès les premières secondes,
• un appel à l’action visible à chaque étape,
• des éléments de réassurance (avis, paiement sécurisé, contact direct),
• des performances techniques, en particulier sur mobile.

La vidéo illustre cette transformation sur un exemple fictif : même contenu de départ, mais une page pensée pour convertir.

Votre site est-il conçu pour générer des opportunités ? Parlons-en : wellwish.fr/contact`,
  tags: tags('web'), video: 'W02' },

/* =============================== SEMAINE 5 =============================== */
{ id: 'WW-13', key: 'M03', theme: 'Mission, vision et valeurs', pillar: 'Identité, mission, valeurs', format: 'Vidéo',
  title: 'Notre vision — Le digital, accélérateur accessible',
  objective: 'Inspirer en fin d’année, porter la vision',
  hook: { ig: 'Le digital n’est pas réservé aux grandes entreprises.', li: 'Le digital n’est pas un privilège de grandes entreprises.' },
  da: 'Vidéo typographique pure sur navy : phrases courtes, mots-clés en dégradé, transitions par masque. Clôture sur le symbole W.',
  cta: { ig: 'Fais du digital un levier de croissance', li: 'Faites du digital un levier de croissance' },
  captionIG: `Le digital n’est pas réservé aux grandes entreprises. 🚀

Notre vision : faire du digital un accélérateur de croissance accessible à toutes les entreprises, quelle que soit leur taille ou leur maturité tech.

Des solutions durables. Évolutives. Intelligentes.
Qui grandissent avec toi.

On attaque l’année avec cette conviction. Et toi, c’est quoi ton projet digital pour cette année ? 👇`,
  textLI: `Le digital n’est pas un privilège de grandes entreprises.

Notre vision chez WELLWISH : faire du digital un accélérateur de croissance accessible à toutes les entreprises, indépendamment de leur taille ou de leur maturité technologique.

Cela suppose de construire des solutions :
→ durables, plutôt que des projets jetables,
→ évolutives, qui suivent la croissance au lieu de la freiner,
→ intelligentes, qui intègrent l’automatisation et l’IA là où elles créent de la valeur.

À l’approche de la nouvelle année, une question : quel projet digital ferait le plus de différence pour votre entreprise en 2027 ?`,
  tags: tags('id'), video: 'M03' },

{ id: 'WW-14', key: 'B03', theme: 'Branding et identité de marque', pillar: 'Expertise & pédagogie', format: 'Carrousel',
  title: 'Lancer une marque : par où commencer ?',
  objective: 'Attirer les porteurs de projet en début d’année',
  hook: { ig: 'Tu veux lancer ta marque mais tu ne sais pas par où commencer ?', li: 'Construire une marque, ce n’est pas simplement créer un produit.' },
  da: 'Feuille de route en 5 étapes, une slide par étape, numéros entre crochets XXL, chip « étape ». Planche de marque illustrative.',
  slides: [
    { l: 'cover', kicker: 'Branding · Lancement', title: { ig: 'Lancer ta *marque* : par où commencer ?', li: 'Lancer une *marque* : par où commencer ?' }, sub: 'Une marque, ce n’est pas seulement un produit.' },
    { l: 'point', num: '01', title: 'Le positionnement.', body: { ig: 'Pour qui ? Contre quoi ? Pourquoi toi plutôt qu’un autre ? Tout le reste en découle.', li: 'Pour qui ? Face à quelles alternatives ? Pourquoi vous ? Tout le reste en découle.' } },
    { l: 'point', num: '02', title: 'Le récit.', body: 'Une histoire, une mission, un ton. Ce qui rend la marque mémorable au-delà du produit.' },
    { l: 'visual', kicker: '03 · L’identité', title: 'Un système visuel, pas juste un logo.', v: { type: 'brand' }, concept: false },
    { l: 'point', num: '04', title: 'Les points de contact.', body: 'Site, boutique, réseaux, packaging : les mêmes codes, partout, dès le premier jour.' },
    { l: 'point', num: '05', title: 'Le lancement.', body: 'Une séquence : teasing, mise en ligne, premières campagnes, mesure. Pas une simple publication.' },
    { l: 'cta', title: { ig: 'Ta marque mérite un vrai *départ*.', li: 'Votre marque mérite un vrai *départ*.' }, cta: { ig: 'Passe de l’idée à l’action', li: 'Passez de l’idée à l’action' } },
  ],
  cta: { ig: 'Passe de l’idée à l’action', li: 'Passez de l’idée à l’action' },
  captionIG: `Tu veux lancer ta marque cette année mais tu ne sais pas par où commencer ? 🧭

Voilà l’ordre qu’on suit :
1. Positionnement — pour qui, pourquoi toi
2. Récit — histoire, mission, ton
3. Identité — un système visuel, pas juste un logo
4. Points de contact — site, réseaux, packaging
5. Lancement — teasing, mise en ligne, campagnes, mesure

Le piège classique : commencer par le logo. 😅

💾 Enregistre ta feuille de route
👉 Prêt·e à passer de l’idée à l’action ? Lien en bio`,
  textLI: `Construire une marque, ce n’est pas simplement créer un produit.

Beaucoup de lancements commencent par le logo. C’est pourtant l’une des dernières étapes d’une démarche de marque solide.

L’ordre que nous recommandons :
1. Positionnement — à qui s’adresse la marque, face à quelles alternatives, avec quelle promesse.
2. Récit — mission, histoire, ton : ce qui rend la marque mémorable au-delà du produit.
3. Identité visuelle — un système complet (symbole, palette, typographie, règles), pas un fichier isolé.
4. Points de contact — site, boutique, réseaux, packaging, supports commerciaux, cohérents dès le premier jour.
5. Lancement — une séquence pensée : teasing, mise en ligne, premières campagnes, mesure.

Vous préparez un lancement cette année ? Passez de l’idée à l’action : wellwish.fr/contact`,
  tags: tags('brand', ['#lancementdemarque']) },

{ id: 'WW-15', key: 'S04', theme: 'SaaS et intelligence artificielle', pillar: 'Intelligence artificielle & innovation', format: 'Carrousel',
  title: 'Intégrer l’IA dans votre activité : par où commencer ?',
  objective: 'Éduquer et rassurer sur l’IA, générer des demandes de cadrage',
  hook: { ig: 'Tu veux mettre de l’IA dans ton activité ? Commence par là.', li: 'Intégrer l’IA dans votre activité : par où commencer ?' },
  da: 'Navy et grille technique pour l’univers IA. Méthode en 4 étapes, conversation d’assistant (concept). Mots-clés en dégradé.',
  slides: [
    { l: 'cover', bg: 'navy', deco: 'grid', kicker: 'IA · Méthode', title: { ig: 'L’IA dans ton activité : *par où* commencer ?', li: 'L’IA dans votre activité : *par où* commencer ?' } },
    { l: 'statement', bg: 'white', deco: null, kicker: 'L’erreur classique', title: 'Partir de l’outil, au lieu de partir du *problème*.', size: 'd-md' },
    { l: 'point', num: '01', title: 'Cartographier les tâches.', body: 'Lesquelles prennent du temps, se répètent, ou reposent sur des documents et des emails ?' },
    { l: 'point', num: '02', title: 'Choisir un cas d’usage précis.', body: 'Un seul, mesurable : qualifier les demandes entrantes, préparer des devis, répondre aux questions fréquentes…' },
    { l: 'visual', bg: 'navy', kicker: '03 · Prototyper', title: { ig: 'Tester sur tes vraies données.', li: 'Tester sur vos vraies données.' }, v: { type: 'chat', msgs: [ { u: true, t: 'Prépare un devis pour la demande de ce matin.' }, { t: 'Devis prérempli à partir du catalogue. Il reste à valider la remise.' } ] }, concept: true },
    { l: 'point', num: '04', title: 'Intégrer, mesurer, étendre.', body: { ig: 'Connecter l’IA à tes outils, garder l’humain dans la boucle, puis passer au cas suivant.', li: 'Connecter l’IA à vos outils, garder l’humain dans la boucle, puis passer au cas suivant.' } },
    { l: 'cta', title: { ig: 'Transformons ton idée en *solution*.', li: 'Transformons votre idée en *solution*.' }, cta: { ig: 'Parlons de ton projet IA', li: 'Parlons de votre projet IA' } },
  ],
  cta: { ig: 'Parlons de ton projet IA', li: 'Transformons votre idée en solution' },
  captionIG: `Tu veux mettre de l’IA dans ton activité ? Commence par là 👇

L’erreur n°1 : partir de l’outil (« il faut qu’on utilise ChatGPT ») au lieu de partir du problème.

La méthode :
1. liste tes tâches répétitives
2. choisis UN cas précis
3. teste sur tes vraies données
4. intègre à tes outils, mesure, puis étends

L’IA n’est pas magique. Bien branchée, elle est redoutablement efficace.

👉 Tu as un cas en tête ? Raconte-le-nous en commentaire.`,
  textLI: `Intégrer l’IA dans votre activité : par où commencer ?

L’erreur la plus fréquente consiste à partir de l’outil plutôt que du problème à résoudre. Résultat : des tests sans lendemain et une conviction que « l’IA, ce n’est pas pour nous ».

La démarche que nous appliquons :
1. Cartographier les tâches chronophages, répétitives, ou fondées sur des documents et des emails.
2. Sélectionner un cas d’usage unique et mesurable.
3. Prototyper sur vos données réelles, pour juger sur pièce.
4. Intégrer la solution à vos outils existants, garder l’humain dans la boucle de validation, mesurer, puis étendre.

Cette approche progressive limite le risque, produit des résultats rapidement visibles et construit la confiance des équipes.

Vous avez identifié un premier cas d’usage ? Transformons votre idée en solution : wellwish.fr/contact`,
  tags: tags('saas') },

/* =============================== SEMAINE 6 =============================== */
{ id: 'WW-16', key: 'E02', theme: 'E-commerce et marketplaces', pillar: 'Démonstrations & réalisations', format: 'Vidéo',
  title: 'Votre boutique en ligne doit être votre meilleur vendeur',
  objective: 'Démontrer une boutique e-commerce performante (concept)',
  hook: { ig: 'Ta boutique en ligne doit être ton meilleur vendeur.', li: 'Votre boutique en ligne doit être votre meilleur vendeur.' },
  da: 'Mockup smartphone : parcours d’achat animé (arrivée → fiche produit → panier → confirmation). Étiquettes qui apparaissent sur chaque élément de réassurance. Concept illustratif.',
  cta: { ig: 'Parlons de ta boutique', li: 'Parlons de votre boutique' },
  captionIG: `Ta boutique en ligne doit être ton meilleur vendeur. 🛍️

Un bon vendeur, en boutique :
→ accueille et oriente
→ répond aux questions
→ rassure
→ conclut

Ta boutique en ligne doit faire exactement pareil, 24h/24 :
fiches produits claires, avis visibles, livraison annoncée, paiement en 2 clics.

(Parcours de la vidéo = exemple illustratif.)

👉 On fait de la tienne ta meilleure vendeuse ? Lien en bio`,
  textLI: `Votre boutique en ligne doit être votre meilleur vendeur.

En magasin, un bon vendeur accueille, oriente, répond aux objections, rassure et conclut. Une boutique en ligne performante remplit exactement les mêmes fonctions, en continu :
• une page d’accueil qui oriente vers les bons produits,
• des fiches produits qui répondent aux questions avant qu’elles ne soient posées,
• des éléments de réassurance au moment où le doute apparaît (avis, livraison, retours),
• un paiement simple et rapide, en particulier sur mobile.

La vidéo illustre ce parcours sur un exemple fictif.

Votre boutique joue-t-elle pleinement ce rôle ? Parlons-en : wellwish.fr/contact`,
  tags: tags('ecom'), video: 'E02' },

{ id: 'WW-17', key: 'A04', theme: 'Publicité et acquisition', pillar: 'Présentation des offres', format: 'Statique',
  title: 'Google, Meta, Instagram, Amazon Ads : un seul pilotage',
  objective: 'Présenter l’offre gestion publicitaire multi-plateforme',
  hook: { ig: '4 plateformes pub. 1 seul pilotage.', li: 'Quatre plateformes publicitaires, une seule logique de pilotage.' },
  da: 'Statique blanc chaud, grand titre, grille 2×2 des plateformes en tuiles, ligne de convergence vers « Rentabilité ».',
  static: { l: 'visual', bg: 'white', kicker: 'Acquisition · Ads', size: 'd-md', title: '4 plateformes.\nUn seul *pilotage*.',
    body: { ig: 'Stratégie, création, retargeting, analyse : pilotés par ce que tes campagnes rapportent.', li: 'Stratégie, création, retargeting, analyse : pilotés par la rentabilité de vos campagnes.' },
    v: { type: 'channels', items: [ { t: 'Google Ads', i: 'target' }, { t: 'Meta Ads', i: 'user' }, { t: 'Instagram Ads', i: 'eye' }, { t: 'Amazon Ads', i: 'cart' } ] } },
  cta: { ig: 'Découvre comment on peut t’accompagner', li: 'Découvrez comment WELLWISH peut vous accompagner' },
  captionIG: `4 plateformes pub. 1 seul pilotage. 📊

Google Ads · Meta Ads · Instagram Ads · Amazon Ads

Chaque plateforme a ses codes, mais une seule question compte : qu’est-ce que ça te rapporte ?

On gère :
→ la stratégie d’acquisition
→ les contenus publicitaires
→ le retargeting
→ l’analyse et l’optimisation du ROAS

Découvre comment on peut t’accompagner → lien en bio`,
  textLI: `Quatre plateformes publicitaires, une seule logique de pilotage.

Google Ads, Meta Ads, Instagram Ads, Amazon Ads : chaque régie a ses formats, ses audiences et ses règles. Gérées séparément, elles produisent des rapports qui ne se comparent pas et des budgets qui ne se répondent pas.

Notre approche consiste à les piloter ensemble, avec un critère commun : la rentabilité.
→ une stratégie d’acquisition par objectif et par audience,
→ des contenus publicitaires conçus pour chaque format,
→ un retargeting cohérent entre les plateformes,
→ une analyse continue et l’optimisation du ROAS.

Découvrez comment WELLWISH peut vous accompagner : wellwish.fr`,
  tags: tags('ads', ['#amazonads']) },

{ id: 'WW-18', key: 'S02', theme: 'SaaS et intelligence artificielle', pillar: 'Problématiques clients & solutions', format: 'Carrousel',
  title: 'Vous n’avez pas besoin de dix logiciels pour gérer votre entreprise',
  objective: 'Leads SaaS sur mesure / centralisation',
  hook: { ig: 'Tu n’as pas besoin de 10 logiciels pour gérer ta boîte.', li: 'Vous n’avez pas besoin de dix logiciels pour gérer votre entreprise.' },
  da: 'Visuel « constellation d’outils » éparpillés, puis le même schéma recentré autour d’un hub WELLWISH (concept). Structure problème → solution.',
  slides: [
    { l: 'cover', kicker: 'SaaS · Centralisation', title: { ig: 'Tu n’as pas besoin de *10 logiciels*.', li: 'Vous n’avez pas besoin de *dix logiciels*.' } },
    { l: 'visual', kicker: 'Le problème', title: 'Un outil par besoin. Aucun ne se parle.', v: { type: 'tools', h: 640, r: 250 } },
    { l: 'list', kicker: 'Les conséquences', title: 'Ce que ça coûte vraiment.', size: 'd-sm', items: [ { t: 'Des données dispersées', s: 'Aucune vue d’ensemble fiable.' }, { t: 'Des doubles saisies', s: 'Et autant d’erreurs possibles.' }, { t: 'Des abonnements qui s’empilent', s: 'Pour des fonctions à moitié utilisées.' } ] },
    { l: 'statement', kicker: 'Le diagnostic', title: 'Le problème n’est pas le *nombre* d’outils. C’est leur dispersion.', size: 'd-md' },
    { l: 'visual', kicker: 'La solution', title: { ig: 'Un outil central, taillé pour tes process.', li: 'Un outil central, taillé pour vos processus.' }, v: { type: 'tools', h: 640, r: 250, hub: true }, concept: true },
    { l: 'statement', bg: 'lav', deco: null, kicker: 'Les bénéfices', title: 'Une seule source de *vérité*.', body: 'Moins de saisie, des décisions plus rapides, un outil qui suit la croissance.', size: 'd-md' },
    { l: 'cta', title: { ig: 'Construisons ta prochaine *solution*.', li: 'Construisons votre prochaine *solution*.' }, cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' } },
  ],
  cta: { ig: 'Parlons de ton projet', li: 'Construisons ensemble votre prochaine solution' },
  captionIG: `Tu n’as pas besoin de 10 logiciels pour gérer ta boîte. 🧩

CRM ici, devis là, factures ailleurs, stock dans un tableur, planning sur un autre outil…
Résultat : des données éparpillées, des doubles saisies, des abonnements qui s’empilent.

Le vrai sujet, ce n’est pas le nombre d’outils. C’est qu’ils ne se parlent pas.

La solution : un outil central, pensé pour TES process, connecté à ce qui doit rester.

👉 Combien d’outils tu utilises au quotidien ? Dis-le en commentaire.`,
  textLI: `Vous n’avez pas besoin de dix logiciels pour gérer votre entreprise.

C’est une situation que nous rencontrons très souvent : un CRM, un outil de devis, un logiciel de facturation, des tableurs pour le stock, un outil de planning… Chacun a été adopté pour une bonne raison. Ensemble, ils créent un système fragmenté.

Les conséquences :
• des données dispersées, sans vue d’ensemble fiable,
• des doubles saisies et les erreurs qui en découlent,
• des abonnements qui s’accumulent pour des fonctions partiellement utilisées.

Le problème n’est pas le nombre d’outils, mais leur dispersion. La réponse peut être un outil métier central, conçu autour de vos processus, connecté aux solutions qui doivent rester en place.

Construisons ensemble votre prochaine solution : wellwish.fr/contact`,
  tags: tags('saas', ['#logicielsurmesure']) },

/* =============================== SEMAINE 7 =============================== */
{ id: 'WW-19', key: 'W03', theme: 'Développement web', pillar: 'Expertise & pédagogie', format: 'Carrousel',
  title: 'Réservation et paiement en ligne : ce qu’un site peut faire pour vous',
  objective: 'Promouvoir les sites avec réservation / paiement',
  hook: { ig: 'Et si ton site prenait les réservations à ta place ?', li: 'Votre site peut-il encaisser et réserver à votre place ?' },
  da: 'Mockups navigateur et parcours de réservation (calendrier → paiement → confirmation) en nœuds. Lavande / blanc, CTA navy.',
  slides: [
    { l: 'cover', kicker: 'Web · Réservation', title: { ig: 'Et si ton site *réservait* à ta place ?', li: 'Et si votre site *réservait* à votre place ?' }, sub: 'Réservation et paiement en ligne, 24 h / 24.' },
    { l: 'statement', kicker: 'Le problème', title: 'Appels manqués, allers-retours, *oublis*.', size: 'd-md', body: { ig: 'Chaque réservation à la main te coûte du temps, et parfois un client.', li: 'Chaque réservation gérée à la main coûte du temps, et parfois un client.' } },
    { l: 'visual', kicker: 'Le parcours', title: 'Trois étapes, zéro échange.', v: { type: 'flow', nodes: [ { i: 'cal', t: 'Le client choisit un créneau' }, { i: 'card', t: 'Il paie ou verse un acompte', auto: true }, { i: 'mail', t: 'Confirmation et rappel envoyés', auto: true } ] }, concept: true },
    { l: 'list', kicker: 'Pour qui', title: 'Les activités qui y gagnent le plus.', size: 'd-sm', items: [ { t: 'Prestations de services et rendez-vous' }, { t: 'Location et activités de loisirs' }, { t: 'Ateliers, formations, événements' } ] },
    { l: 'list', kicker: 'Les bénéfices', title: 'Ce que ça change.', size: 'd-sm', items: [ { t: 'Des réservations même la nuit' }, { t: 'Moins de rendez-vous non honorés', s: 'Grâce à l’acompte et aux rappels.' }, { t: 'Un agenda toujours à jour' } ] },
    { l: 'cta', title: { ig: 'Ton site peut faire *plus*.', li: 'Votre site peut faire *plus*.' }, cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' } },
  ],
  cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' },
  captionIG: `Et si ton site prenait les réservations à ta place ? 📅

Fini les appels manqués et les « tu as un créneau mardi ? ».

Avec la réservation + paiement en ligne :
1. ton client choisit son créneau
2. il paie ou laisse un acompte
3. confirmation et rappel partent tout seuls

Idéal pour les prestations de services, la location, les ateliers, les événements…

👉 Ton activité pourrait en profiter ? Parle-nous en, lien en bio.`,
  textLI: `Votre site peut-il encaisser et réserver à votre place ?

Pour de nombreuses activités de services, la prise de rendez-vous reste manuelle : appels, emails, allers-retours, oublis. Un temps important, et des clients perdus lorsqu’on ne répond pas assez vite.

Un site avec réservation et paiement en ligne automatise ce parcours :
1. le client choisit un créneau disponible,
2. il règle sa prestation ou verse un acompte,
3. la confirmation et les rappels sont envoyés automatiquement.

Les bénéfices : des réservations possibles à toute heure, moins de rendez-vous non honorés grâce à l’acompte et aux rappels, un agenda toujours à jour.

Prestations de services, location, ateliers, formations, événements : parlons de votre projet. wellwish.fr/contact`,
  tags: tags('web', ['#reservationenligne']) },

{ id: 'WW-20', key: 'C02', theme: 'Problématiques clients', pillar: 'Démonstrations & réalisations', format: 'Vidéo',
  title: 'Mes données sont dispersées',
  objective: 'Démontrer la centralisation / automatisation des données (concept)',
  hook: { ig: 'Tes données sont partout. Sauf là où tu en as besoin.', li: 'Vos données sont partout. Sauf là où vous en avez besoin.' },
  da: 'Animation de fichiers et tableurs éparpillés qui convergent vers un dashboard unifié (données fictives). Particules / lignes de flux, rythme rapide.',
  cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' },
  captionIG: `Tes données sont partout. Sauf là où tu en as besoin. 📂

Un tableur pour les ventes, un autre pour le stock, le CRM d’un côté, la compta de l’autre…
Et chaque fin de mois : 3 heures pour tout recoller.

La solution : centraliser et automatiser.
Tes outils envoient leurs données au même endroit → un tableau de bord à jour, tout seul.

(Dashboard de la vidéo = données fictives.)

👉 On centralise les tiennes ? Lien en bio.`,
  textLI: `Vos données sont partout. Sauf là où vous en avez besoin.

Ventes dans un tableur, stock dans un autre, CRM, outil comptable, exports de plateformes… Dans beaucoup d’entreprises, la donnée existe mais elle est dispersée. Chaque reporting devient une opération manuelle, longue et sujette aux erreurs.

La centralisation consiste à faire converger automatiquement ces sources vers un référentiel unique, et à en tirer un tableau de bord à jour en permanence.

Les bénéfices :
• un temps de reporting drastiquement réduit,
• des indicateurs fiables et partagés,
• des décisions prises sur des données actuelles plutôt que sur des exports anciens.

La vidéo illustre ce principe avec des données fictives. Parlons de votre cas : wellwish.fr/contact`,
  tags: tags('pb', ['#data']), video: 'C02' },

{ id: 'WW-21', key: 'B01', theme: 'Branding et identité de marque', pillar: 'Problématiques clients & solutions', format: 'Carrousel',
  title: 'Votre marque mérite mieux qu’un simple logo',
  objective: 'Leads branding — faire comprendre la notion de système de marque',
  hook: { ig: 'Ta marque mérite mieux qu’un simple logo.', li: 'Votre marque mérite mieux qu’un simple logo.' },
  da: 'Comparaison « logo seul » vs « système de marque » en colonnes, planche d’identité illustrative. Couverture lavande, dégradé sur un mot.',
  slides: [
    { l: 'cover', kicker: 'Branding', title: { ig: 'Ta marque mérite mieux qu’un *logo*.', li: 'Votre marque mérite mieux qu’un *logo*.' } },
    { l: 'list', kicker: 'Les symptômes', title: { ig: 'Tu te reconnais ?', li: 'Vous vous reconnaissez ?' }, size: 'd-md', items: [ { t: 'Une identité qui manque de professionnalisme' }, { t: 'Des supports qui ne se ressemblent pas' }, { t: 'Une marque qu’on confond avec la concurrence' } ] },
    { l: 'statement', kicker: 'Les conséquences', title: 'Moins de confiance. Moins de *mémorisation*. Des prix plus difficiles à défendre.', size: 'd-md' },
    { l: 'vs', kicker: 'Le diagnostic', title: 'Logo seul ou *système* de marque ?', bad: { h: 'Logo seul', r: ['Un fichier', 'Utilisé au hasard', 'Aucune règle'] }, good: { h: 'Système de marque', r: ['Symbole, couleurs, typo', 'Règles d’usage', 'Déclinaisons prêtes'] } },
    { l: 'visual', kicker: 'La solution', title: 'Une identité pensée pour tous les supports.', v: { type: 'brand' } },
    { l: 'statement', bg: 'lav', deco: null, kicker: 'Les bénéfices', title: 'Reconnu en une *seconde*, partout.', size: 'd-md', body: 'Une marque cohérente inspire confiance et se retient.' },
    { l: 'cta', title: { ig: 'Donne une nouvelle *dimension* à ta marque.', li: 'Donnez une nouvelle *dimension* à votre marque.' }, cta: { ig: 'Construisons ta marque', li: 'Parlons de votre marque' } },
  ],
  cta: { ig: 'Construisons ta marque', li: 'Parlons de votre marque' },
  captionIG: `Ta marque mérite mieux qu’un simple logo. ✍️

Un logo, c’est un fichier.
Une marque, c’est un système :
→ un symbole
→ une palette
→ une typo
→ des règles d’usage
→ des déclinaisons pour chaque support

Sans système, chaque visuel est différent… et personne ne te reconnaît.

Ton identité est-elle cohérente partout ? Fais le test : aligne ton site, ton Insta et ta carte de visite. 👀

👉 Envie d’un vrai système de marque ? Lien en bio.`,
  textLI: `Votre marque mérite mieux qu’un simple logo.

Une identité qui manque de professionnalisme, des supports qui ne se ressemblent pas, une marque difficile à distinguer de ses concurrents : ces symptômes ont souvent la même origine. L’entreprise dispose d’un logo, mais pas d’un système de marque.

La différence est déterminante :
• un logo est un fichier ;
• un système de marque réunit un symbole, une palette, une typographie, des règles d’usage et des déclinaisons prêtes pour chaque support.

Les conséquences d’une identité incohérente sont concrètes : moins de confiance, moins de mémorisation, et des prix plus difficiles à défendre.

Donnez une nouvelle dimension à votre marque : wellwish.fr/contact`,
  tags: tags('brand') },

/* =============================== SEMAINE 8 =============================== */
{ id: 'WW-22', key: 'E03', theme: 'E-commerce et marketplaces', pillar: 'Problématiques clients & solutions', format: 'Carrousel',
  title: 'Vous dépendez uniquement des marketplaces ?',
  objective: 'Leads e-commerce omnicanal / site de marque',
  hook: { ig: 'Tout ton CA vient d’une seule marketplace ? Danger.', li: 'Dépendre d’une seule marketplace est un risque business.' },
  da: 'Schéma canaux : marketplaces + boutique en propre reliées à la marque. Ton analytique, couverture blanc chaud.',
  slides: [
    { l: 'cover', kicker: 'E-commerce · Canaux', title: { ig: 'Ton CA dépend d’*une seule* plateforme ?', li: 'Votre CA dépend-il d’*une seule* plateforme ?' } },
    { l: 'list', kicker: 'Le risque', title: { ig: 'Ce que tu ne contrôles pas.', li: 'Ce que vous ne contrôlez pas.' }, size: 'd-sm', items: [ { t: 'Les règles et les commissions', s: 'Elles peuvent évoluer sans préavis.' }, { t: 'La relation client', s: 'Les données d’achat restent sur la plateforme.' }, { t: 'La visibilité', s: 'Un changement d’algorithme, et les ventes chutent.' } ] },
    { l: 'statement', kicker: 'Le diagnostic', title: 'Les marketplaces sont un *canal*. Pas une stratégie.', size: 'd-md' },
    { l: 'visual', kicker: 'La solution', title: 'Une marque, plusieurs canaux qui se renforcent.', v: { type: 'loop', steps: [ { i: 'box', t: 'Marketplaces' }, { i: 'cart', t: 'Boutique en propre' }, { i: 'mail', t: 'Clients fidélisés' }, { i: 'target', t: 'Acquisition' } ] } },
    { l: 'list', kicker: 'Les bénéfices', title: { ig: 'Ce que tu reprends en main.', li: 'Ce que vous reprenez en main.' }, size: 'd-sm', items: [ { t: { ig: 'Tes marges', li: 'Vos marges' } }, { t: { ig: 'Tes données clients', li: 'Vos données clients' } }, { t: { ig: 'Ton image de marque', li: 'Votre image de marque' } } ] },
    { l: 'cta', title: { ig: 'Développe ta marque *en ligne*.', li: 'Développez votre marque *en ligne*.' }, cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' } },
  ],
  cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' },
  captionIG: `Tout ton CA vient d’une seule marketplace ? ⚠️

Les marketplaces sont un super canal. Mais si elles sont ton SEUL canal :
→ tu subis leurs règles et leurs commissions
→ tes données clients ne t’appartiennent pas
→ un changement d’algorithme et tes ventes plongent

La bonne approche : marketplaces + boutique en propre + fidélisation, qui se renforcent.

👉 Tu veux reprendre la main sur ta marque ? Lien en bio`,
  textLI: `Dépendre d’une seule marketplace est un risque business.

Les marketplaces offrent une audience considérable et un accès rapide au marché. Mais lorsqu’elles concentrent l’essentiel du chiffre d’affaires, l’entreprise perd la maîtrise de plusieurs leviers critiques :
• les règles et les commissions, qui peuvent évoluer à tout moment,
• la relation client, dont les données restent sur la plateforme,
• la visibilité, soumise aux évolutions des algorithmes.

Les marketplaces sont un canal, pas une stratégie. L’enjeu est de construire un écosystème où marketplaces, boutique en propre, fidélisation et acquisition se renforcent mutuellement.

Vous souhaitez rééquilibrer vos canaux de vente ? Parlons-en : wellwish.fr/contact`,
  tags: tags('ecom', ['#omnicanal']) },

{ id: 'WW-23', key: 'A02', theme: 'Publicité et acquisition', pillar: 'Expertise & pédagogie', format: 'Vidéo',
  title: 'ROAS, CPA, conversion : ce que vos dashboards doivent vous dire',
  objective: 'Pédagogie sur les indicateurs publicitaires',
  hook: { ig: 'ROAS, CPA, conversion : 3 chiffres à comprendre avant de booster une pub.', li: 'Trois indicateurs à maîtriser avant d’augmenter un budget publicitaire.' },
  da: 'Dashboard animé (données fictives) : les trois KPI s’allument un par un avec leur définition en typographie animée. Fond lavande puis navy.',
  cta: { ig: 'Parlons de tes campagnes', li: 'Contactez-nous pour échanger sur vos besoins' },
  captionIG: `3 chiffres à comprendre avant de booster une pub. 📈

ROAS → ce que rapporte 1 € investi en pub
CPA → ce que te coûte une vente (ou un lead)
Taux de conversion → la part de visiteurs qui passent à l’action

Si tu ne connais pas ces 3 chiffres pour tes campagnes, tu pilotes à l’aveugle.

(Dashboard de la vidéo = données fictives.)

💾 Enregistre cette vidéo
👉 On t’aide à les suivre ? Lien en bio.`,
  textLI: `Trois indicateurs à maîtriser avant d’augmenter un budget publicitaire.

ROAS (Return On Ad Spend) — le chiffre d’affaires généré pour chaque euro investi en publicité.
CPA (Coût Par Acquisition) — le coût d’obtention d’une vente ou d’un contact qualifié.
Taux de conversion — la proportion de visiteurs qui réalisent l’action attendue.

Pris isolément, aucun ne suffit. Un ROAS élevé sur un volume minime, un CPA bas sur des leads non qualifiés, un bon taux de conversion sur une audience trop restreinte : c’est leur lecture combinée, rapportée à vos marges, qui permet de décider où investir.

La vidéo illustre ces indicateurs avec des données fictives.

Contactez-nous pour échanger sur le pilotage de vos campagnes : wellwish.fr/contact`,
  tags: tags('ads'), video: 'A02' },

{ id: 'WW-24', key: 'C03', theme: 'Problématiques clients', pillar: 'Problématiques clients & solutions', format: 'Statique',
  title: 'Mon coût d’acquisition est trop élevé',
  objective: 'Interpeller sur le coût d’acquisition, générer des conversations',
  hook: { ig: '« Mon coût d’acquisition est trop élevé. »', li: '« Notre coût d’acquisition est trop élevé. »' },
  da: 'Statique en citation : phrase du client en Bricolage, puis 3 leviers en liste. Fond blanc chaud, guillemets violet.',
  static: { l: 'list', bg: 'white', kicker: 'Problématique client', size: 'd-md',
    title: { ig: '« Mon coût d’acquisition est trop *élevé*. »', li: '« Notre coût d’acquisition est trop *élevé*. »' },
    items: [ { t: 'Mieux cibler', s: 'Concentrer le budget sur les audiences qui achètent.' }, { t: 'Mieux convertir', s: 'Une page d’arrivée qui transforme le clic payé.' }, { t: 'Mieux fidéliser', s: 'Un client qui revient ne se rachète pas.' } ] },
  cta: { ig: 'Parlons de ton acquisition', li: 'Contactez-nous pour échanger sur vos besoins' },
  captionIG: `« Mon coût d’acquisition est trop élevé. » 😩

On l’entend souvent. Et la réponse n’est presque jamais « mets plus de budget ».

3 leviers à activer :
1. mieux cibler → le budget va vers ceux qui achètent
2. mieux convertir → ta page transforme le clic payé
3. mieux fidéliser → un client qui revient ne se rachète pas

Lequel est ton point faible ? Dis-le en commentaire 👇`,
  textLI: `« Notre coût d’acquisition est trop élevé. »

C’est l’une des préoccupations les plus fréquentes que nous partagent les dirigeants. La réponse instinctive — augmenter les budgets — l’aggrave souvent.

Trois leviers permettent d’agir durablement :
1. Mieux cibler : concentrer les investissements sur les audiences qui convertissent réellement.
2. Mieux convertir : chaque point gagné sur la page d’arrivée réduit mécaniquement le coût de chaque acquisition.
3. Mieux fidéliser : un client qui revient n’a pas à être racheté. La valeur client sur la durée rend acceptable un coût d’acquisition qui ne l’était pas sur une seule commande.

Lequel de ces leviers est aujourd’hui le moins exploité dans votre entreprise ?`,
  tags: tags('ads', ['#CAC']) },

/* =============================== SEMAINE 9 =============================== */
{ id: 'WW-25', key: 'F01', theme: 'Forces et différenciation', pillar: 'Présentation des offres', format: 'Carrousel',
  title: 'Double expertise : technologie et marketing',
  objective: 'Différenciation — expliquer l’approche 360°',
  hook: { ig: 'Les devs ne parlent pas marketing. Les marketeurs ne parlent pas tech. Nous, si.', li: 'Pourquoi la double expertise technologie × marketing change tout.' },
  da: 'Deux colonnes Tech / Marketing qui se rejoignent, puis méthode en 4 temps. Navy et blanc alternés, dégradé sur « 360° ».',
  slides: [
    { l: 'cover', bg: 'navy', deco: 'grid', kicker: 'Nos forces', title: 'Tech *×* marketing. Dans la même équipe.' },
    { l: 'statement', bg: 'white', deco: null, kicker: 'Le problème', title: 'Le développeur ne parle pas *conversion*. Le marketeur ne parle pas API.', size: 'd-md', body: 'Et le projet se perd entre les deux.' },
    { l: 'vs', kicker: 'La différence', title: 'Deux prestataires ou une *équipe* ?', bad: { h: 'Prestataires séparés', r: ['Briefs multiples', 'Responsabilités floues', 'Outils qui ne se parlent pas'] }, good: { h: 'Approche 360°', r: ['Un seul interlocuteur', 'Une vision d’ensemble', 'Tech et marketing alignés'] } },
    { l: 'list', kicker: 'Nos forces', title: 'Ce qui nous distingue.', size: 'd-sm', items: [ { t: 'Une compréhension concrète de l’e-commerce' }, { t: 'Des solutions sur mesure, IA incluse' }, { t: 'Une approche orientée rentabilité' }, { t: 'Plusieurs écosystèmes maîtrisés' } ] },
    { l: 'list', bg: 'lav', kicker: 'Notre méthode', title: 'De la réflexion au déploiement.', size: 'd-sm', items: [ { t: 'Comprendre', s: { ig: 'Tes enjeux et ton activité.', li: 'Vos enjeux et votre activité.' } }, { t: 'Concevoir', s: 'La solution qui y répond.' }, { t: 'Produire', s: 'Développer, créer, intégrer.' }, { t: 'Développer', s: 'Mesurer et faire évoluer.' } ] },
    { l: 'cta', title: 'Un projet, une *équipe*, une vision.', cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' } },
  ],
  cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' },
  captionIG: `Les devs ne parlent pas marketing. Les marketeurs ne parlent pas tech. Nous, on parle les deux. 🧠

Pourquoi c’est important ?
Parce qu’un site, une boutique ou une appli ne servent à rien si personne ne les trouve. Et une campagne ne sert à rien si l’outil derrière ne convertit pas.

Chez WELLWISH :
→ 1 seul interlocuteur
→ tech + marketing + e-commerce alignés
→ de la réflexion jusqu’au déploiement

👉 Parlons de ton projet, lien en bio.`,
  textLI: `Pourquoi la double expertise technologie × marketing change tout.

Dans un projet digital classique, le développeur raisonne en fonctionnalités, le marketeur en messages et en audiences. Chacun fait bien son travail — mais personne ne porte la vision d’ensemble. Résultat : des briefs multiples, des responsabilités floues et des outils qui ne se parlent pas.

Notre approche repose sur l’inverse :
• un interlocuteur unique, capable de comprendre les dimensions techniques, marketing et économiques d’un projet,
• une compréhension concrète des enjeux e-commerce,
• des solutions sur mesure qui intègrent l’IA lorsque c’est pertinent,
• une méthode en quatre temps : comprendre, concevoir, produire, développer.

Un projet, une équipe, une vision. Parlons de votre projet : wellwish.fr/contact`,
  tags: tags('id') },

{ id: 'WW-26', key: 'S03', theme: 'SaaS et intelligence artificielle', pillar: 'Démonstrations & réalisations', format: 'Vidéo',
  title: 'Et si nous transformions votre idée en logiciel ?',
  objective: 'Démontrer le passage idée → maquette → logiciel (concept)',
  hook: { ig: 'Et si on transformait ton idée en logiciel ?', li: 'Et si nous transformions votre idée en logiciel ?' },
  da: 'Une note manuscrite stylisée « idée » devient wireframe, puis interface SaaS complète (dashboard illustratif), en 3 morphings. Typo animée entre les étapes.',
  cta: { ig: 'Transformons ton idée en solution', li: 'Transformons votre idée en solution' },
  captionIG: `Et si on transformait ton idée en logiciel ? 💡→💻

Tu as un process qu’aucun logiciel du marché ne gère bien ?
Une idée de SaaS qui te trotte dans la tête ?

Le chemin :
1. idée → on la challenge
2. maquette → on la rend concrète
3. logiciel → on le développe, on le déploie, on le fait évoluer

(Interface de la vidéo = exemple illustratif.)

👉 Raconte-nous ton idée, lien en bio.`,
  textLI: `Et si nous transformions votre idée en logiciel ?

Un processus métier qu’aucune solution du marché ne couvre correctement. Une idée de SaaS identifiée sur le terrain. Un outil interne devenu indispensable mais qui repose sur des tableurs.

Notre démarche :
1. Challenger l’idée : quel problème, pour quels utilisateurs, avec quelle valeur.
2. La rendre tangible : parcours, maquettes, priorisation des fonctionnalités.
3. Développer, déployer et faire évoluer : une première version utile rapidement, puis des itérations guidées par l’usage.

La vidéo illustre ce cheminement sur un exemple fictif.

Transformons votre idée en solution : wellwish.fr/contact`,
  tags: tags('saas', ['#webapp']), video: 'S03' },

{ id: 'WW-27', key: 'E04', theme: 'E-commerce et marketplaces', pillar: 'Expertise & pédagogie', format: 'Carrousel',
  title: 'Automatiser vos flux e-commerce',
  objective: 'Pédagogie automatisation e-commerce, leads',
  hook: { ig: 'Tes opérations e-commerce sont trop manuelles ?', li: 'Vos opérations e-commerce sont-elles trop manuelles ?' },
  da: 'Flux d’une commande automatisée en nœuds (illustratif). Liste des flux automatisables, couverture lavande + orbe.',
  slides: [
    { l: 'cover', kicker: 'E-commerce · Opérations', title: { ig: 'Tes opérations e-commerce sont trop *manuelles* ?', li: 'Vos opérations e-commerce sont-elles trop *manuelles* ?' } },
    { l: 'list', kicker: 'Ce qui prend du temps', title: 'Les tâches qui grossissent avec les ventes.', size: 'd-sm', items: [ { t: 'Mettre à jour stocks et prix', s: 'Sur chaque canal, à la main.' }, { t: 'Traiter les commandes', s: 'Ressaisies d’un outil à l’autre.' }, { t: 'Gérer le catalogue', s: 'Fiches à créer et corriger une par une.' } ] },
    { l: 'visual', kicker: 'Le flux automatisé', title: 'Une commande, zéro ressaisie.', v: { type: 'flow', nodes: [ { i: 'cart', t: 'Commande reçue' }, { i: 'box', t: 'Stock mis à jour partout', auto: true }, { i: 'doc', t: 'Facture générée', auto: true }, { i: 'mail', t: 'Suivi envoyé au client', auto: true } ] }, concept: true },
    { l: 'list', kicker: 'Aussi automatisable', title: 'Les autres flux clés.', size: 'd-sm', items: [ { t: 'Synchronisation boutique ↔ marketplaces' }, { t: 'Enrichissement des fiches produits' }, { t: 'Alertes de rupture et réassort' } ] },
    { l: 'statement', bg: 'lav', deco: null, kicker: 'Le bénéfice', title: 'Vendre plus *sans* recruter pour ressaisir.', size: 'd-md' },
    { l: 'cta', title: { ig: 'Fais du digital un *levier* de croissance.', li: 'Faites du digital un *levier* de croissance.' }, cta: { ig: 'Parlons de ta boutique', li: 'Parlons de votre boutique' } },
  ],
  cta: { ig: 'Parlons de ta boutique', li: 'Parlons de votre boutique' },
  captionIG: `Tes opérations e-commerce sont trop manuelles ? ⚙️

Stocks à mettre à jour sur chaque canal, commandes ressaisies, fiches produits corrigées une par une…
Plus tu vends, plus tu passes de temps à… ressaisir.

Ce qui s’automatise :
→ stocks et prix synchronisés partout
→ factures générées toutes seules
→ suivi envoyé au client
→ alertes de rupture

Vendre plus sans recruter pour faire du copier-coller. 🙌

👉 On regarde tes flux ? Lien en bio`,
  textLI: `Vos opérations e-commerce sont-elles trop manuelles ?

Mise à jour des stocks et des prix sur chaque canal, ressaisie des commandes, création et correction des fiches produits… Ces tâches ont une particularité : elles augmentent avec les ventes. La croissance se traduit alors par une charge opérationnelle supplémentaire, plutôt que par de la marge.

Les flux les plus souvent automatisables :
• synchronisation des stocks et des prix entre boutique et marketplaces,
• traitement des commandes, facturation et notifications client,
• enrichissement et mise à jour du catalogue,
• alertes de rupture et de réassort.

L’objectif : vendre plus sans multiplier les tâches de ressaisie.

Faites du digital un levier de croissance : wellwish.fr/contact`,
  tags: tags('ecom', ['#automatisation']) },

/* =============================== SEMAINE 10 ============================== */
{ id: 'WW-28', key: 'A03', theme: 'Publicité et acquisition', pillar: 'Expertise & pédagogie', format: 'Carrousel',
  title: 'Le retargeting expliqué simplement',
  objective: 'Pédagogie retargeting, crédibilité experte',
  hook: { ig: 'Le retargeting expliqué simplement (et pourquoi tu en as besoin).', li: 'Le retargeting expliqué simplement.' },
  da: 'Boucle visiteur → intérêt → relance → retour → achat en schéma circulaire. Couverture lavande, slides blanc chaud.',
  slides: [
    { l: 'cover', kicker: 'Acquisition · Pédagogie', title: 'Le *retargeting*, expliqué simplement.' },
    { l: 'statement', kicker: 'Le constat', title: 'La plupart des visiteurs n’achètent pas à la *première* visite.', size: 'd-md', body: 'Ils comparent, réfléchissent, oublient.' },
    { l: 'point', num: '?', title: 'Le retargeting, c’est quoi ?', body: 'Montrer une publicité ciblée aux personnes qui ont déjà visité le site, consulté un produit ou laissé un panier.' },
    { l: 'visual', kicker: 'Comment ça marche', title: 'Une boucle qui ramène les visiteurs chauds.', v: { type: 'loop', steps: [ { i: 'eye', t: 'Visite' }, { i: 'cart', t: 'Intérêt' }, { i: 'target', t: 'Relance pub' }, { i: 'check', t: 'Achat' } ] } },
    { l: 'list', kicker: 'Les règles', title: 'Bien le faire.', size: 'd-sm', items: [ { t: 'Un message adapté à l’étape', s: 'On ne parle pas pareil à un visiteur et à un panier abandonné.' }, { t: 'Une fréquence maîtrisée', s: 'Relancer, pas harceler.' }, { t: 'Exclure les acheteurs', s: 'Inutile de payer pour convaincre un client déjà convaincu.' } ] },
    { l: 'cta', title: { ig: 'Fais revenir tes visiteurs les plus *chauds*.', li: 'Faites revenir vos visiteurs les plus *chauds*.' }, cta: { ig: 'Parlons de tes campagnes', li: 'Contactez-nous' } },
  ],
  cta: { ig: 'Parlons de tes campagnes', li: 'Contactez-nous pour échanger sur vos besoins' },
  captionIG: `Le retargeting, expliqué simplement. 🎯

La plupart de tes visiteurs n’achètent pas du premier coup. Ils comparent, hésitent, oublient.

Le retargeting = montrer une pub à ceux qui ont DÉJÀ vu ton site, un produit, ou laissé un panier.

Les 3 règles :
1. un message adapté à l’étape
2. une fréquence maîtrisée (relancer ≠ harceler)
3. exclure ceux qui ont déjà acheté

💾 Enregistre pour plus tard
👉 Tu veux le mettre en place ? Lien en bio`,
  textLI: `Le retargeting expliqué simplement.

Sur un site e-commerce comme sur un site de services, la majorité des visiteurs ne passent pas à l’action lors de leur première visite. Ils comparent, réfléchissent, sont interrompus.

Le retargeting consiste à diffuser des publicités ciblées auprès des personnes ayant déjà interagi avec votre marque : visite du site, consultation d’un produit, panier abandonné.

Trois règles pour qu’il soit efficace et rentable :
1. adapter le message à l’étape du parcours,
2. maîtriser la fréquence d’exposition,
3. exclure les personnes ayant déjà converti.

Bien paramétré, c’est souvent l’un des leviers d’acquisition les plus rentables, car il s’adresse à une audience déjà intéressée.

Contactez-nous pour échanger sur vos campagnes : wellwish.fr/contact`,
  tags: tags('ads', ['#retargeting']) },

{ id: 'WW-29', key: 'C04', theme: 'Problématiques clients', pillar: 'Problématiques clients & solutions', format: 'Statique',
  title: 'Ma communication manque de cohérence',
  objective: 'Leads communication digitale / gestion des réseaux',
  hook: { ig: 'Tu postes quand tu as le temps ? Ça se voit.', li: 'Une communication irrégulière coûte plus cher qu’elle n’y paraît.' },
  da: 'Statique avant/après : à gauche un fil de posts incohérents (gris), à droite un fil aligné sur la charte. Fond lavande.',
  static: { l: 'vs', bg: 'lav', kicker: 'Communication digitale', size: 'd-md',
    title: { ig: 'Tu postes quand tu as le temps ? *Ça se voit.*', li: 'Communication irrégulière ? *Ça se voit.*' },
    bad: { h: 'Au coup par coup', r: ['Des visuels disparates', 'Des silences de plusieurs semaines', 'Aucun objectif'] },
    good: { h: 'Avec une stratégie', r: ['Une ligne éditoriale', 'Un rythme tenu', 'Des contenus qui servent la vente'] } },
  cta: { ig: 'Donne une nouvelle dimension à ta présence digitale', li: 'Donnez une nouvelle dimension à votre présence digitale' },
  captionIG: `Tu postes quand tu as le temps ? Ça se voit. 😬

Des visuels qui ne se ressemblent pas. 3 posts en une semaine, puis plus rien pendant un mois. Aucun objectif derrière.

Ce qui change tout :
→ une ligne éditoriale claire
→ un rythme tenu dans la durée
→ des contenus qui servent ta vente, pas juste ton feed

La régularité bat l’inspiration. ✨

👉 Donne une nouvelle dimension à ta présence digitale : lien en bio`,
  textLI: `Une communication irrégulière coûte plus cher qu’elle n’y paraît.

Des visuels disparates, des publications concentrées sur quelques jours puis des semaines de silence, des contenus sans objectif défini : c’est le schéma de nombreuses entreprises qui communiquent « quand elles ont le temps ».

Le coût est réel : une marque moins identifiable, une audience qui se désengage, et des contenus qui ne contribuent pas au développement commercial.

Une communication digitale efficace repose sur trois piliers :
• une ligne éditoriale alignée sur vos objectifs,
• un rythme de publication tenu dans la durée,
• des contenus conçus pour servir votre stratégie commerciale.

Donnez une nouvelle dimension à votre présence digitale : wellwish.fr/contact`,
  tags: tags('pb', ['#communicationdigitale']) },

{ id: 'WW-30', key: 'F02', theme: 'Forces et différenciation', pillar: 'Présentation des offres', format: 'Vidéo',
  title: 'De la réflexion au déploiement : un seul interlocuteur',
  objective: 'Conversion — clôturer la campagne sur l’accompagnement complet',
  hook: { ig: 'Un seul interlocuteur. De l’idée au lancement.', li: 'De la réflexion au déploiement, un seul interlocuteur.' },
  da: 'Timeline horizontale animée en 4 étapes (Comprendre → Concevoir → Produire → Développer), chaque étape révèle un visuel (atelier, maquette, code, dashboard). Clôture logo animé + CTA.',
  cta: { ig: 'Construisons ta prochaine solution', li: 'Construisons ensemble votre prochaine solution' },
  captionIG: `Un seul interlocuteur. De l’idée au lancement. 🤝

Comprendre → on part de ton activité
Concevoir → on dessine la bonne solution
Produire → on développe, on crée, on intègre
Développer → on mesure et on fait évoluer

Pas de relais entre 4 prestataires. Pas d’infos perdues en route.

Merci d’avoir suivi cette première série 🙏
👉 Et maintenant ? Parlons de ton projet. Lien en bio.`,
  textLI: `De la réflexion au déploiement, un seul interlocuteur.

C’est sans doute ce qui résume le mieux la manière dont WELLWISH accompagne ses clients :
1. Comprendre — votre activité, vos enjeux, vos contraintes.
2. Concevoir — la solution la plus adaptée, technologique, marketing ou les deux.
3. Produire — développer, créer, intégrer.
4. Développer — mesurer, optimiser, faire évoluer dans la durée.

À chaque étape, le même interlocuteur. Moins de pertes d’information, des décisions plus rapides et une cohérence préservée de bout en bout.

Ce contenu clôt notre première série. Si l’un des sujets abordés fait écho à vos enjeux, construisons ensemble votre prochaine solution : wellwish.fr/contact`,
  tags: tags('id'), video: 'F02' },
/* ======================= HORS CAMPAGNE — PRÉSENTATION ======================= */
/* WW-31 — demandé par Filipe le 24/11 : un carrousel de présentation en quatre
   temps (qui · à qui · quoi · ce qu'on a fait), ton nettement plus marketing.

   ⚠️ TOUT CE QUI EST CITÉ EST DÉJÀ PUBLIC SUR wellwish.fr. Les huit noms
   — CARGIO, TRACKNPROFIT, INZO, MYMONEYPILOT, SOUNDSWEALTH, WELLKITCH, ESLAY,
   BUSINESSWIN — sont affichés sur la page Projets. Aucun chiffre, aucun
   résultat, aucun client non publié : l'argument de vente est ce qui a été
   CONSTRUIT, pas une performance invérifiable. */
{ id: 'WW-31', key: 'P07', theme: 'Présentation de WELLWISH', pillar: 'Identité, mission, valeurs', format: 'Carrousel',
  title: 'Qui sommes-nous — et qu’avons-nous déjà construit',
  objective: 'Présenter l’agence par la preuve : ce qu’elle a construit, pas ce qu’elle promet',
  hook: { ig: 'On ne conseille pas depuis le bord du terrain.', li: 'Nous ne conseillons pas depuis le bord du terrain.' },
  da: 'Quatre temps — qui, à qui, quoi, ce qu’on a fait. Rythme lavande → navy → blanc, les réalisations en listes nommées, contraste final en vis-à-vis.',
  slides: [
    { l: 'cover', kicker: 'WELLWISH · Qui sommes-nous',
      title: { ig: 'On ne conseille pas depuis le *bord* du terrain.', li: 'Nous ne conseillons pas depuis le *bord* du terrain.' },
      sub: { ig: 'Qui on est, pour qui on travaille, ce qu’on fait — et ce qu’on a déjà construit.', li: 'Qui nous sommes, pour qui nous travaillons, ce que nous faisons — et ce que nous avons déjà construit.' },
      size: 'd-lg' },

    { l: 'statement', bg: 'navy', kicker: '01 · Qui sommes-nous',
      title: { ig: 'Une agence qui construit aussi ses *propres* marques et ses propres logiciels.', li: 'Une agence qui construit aussi ses *propres* marques et ses propres logiciels.' },
      body: { ig: 'Agence digitale & webmarketing — et opérateur de ses propres activités. Ce qu’on te recommande, on se l’applique d’abord.', li: 'Agence digitale & webmarketing — et opérateur de ses propres activités. Ce que nous recommandons, nous nous l’appliquons d’abord.' },
      size: 'd-md' },

    { l: 'list', kicker: '02 · À qui nous nous adressons',
      title: { ig: 'À ceux qui ont une activité à faire tourner.', li: 'À ceux qui ont une activité à faire tourner.' },
      size: 'd-md',
      items: [
        { t: 'Entrepreneurs et indépendants', s: { ig: 'Tu lances, il te faut une présence qui tienne debout.', li: 'Vous lancez : il vous faut une présence qui tienne debout.' } },
        { t: 'TPE et PME', s: { ig: 'Tu veux vendre plus, sans ajouter cinq prestataires.', li: 'Vous voulez vendre plus, sans ajouter cinq prestataires.' } },
        { t: 'Marques et e-commerçants', s: { ig: 'Tu veux tes propres canaux, pas seulement les marketplaces.', li: 'Vous voulez vos propres canaux, pas seulement les marketplaces.' } },
        { t: 'Entreprises avec un process à outiller', s: { ig: 'Ton métier ne rentre pas dans un logiciel du marché.', li: 'Votre métier ne rentre pas dans un logiciel du marché.' } },
      ] },

    { l: 'list', kicker: '03 · Ce que nous faisons',
      title: 'Six expertises, une seule équipe.',
      size: 'd-md',
      /* ⚠️ SIX LIGNES SANS SOUS-TITRE. Avec le détail sous chaque intitulé,
         la sixième ligne venait buter sur le bandeau de pied — « Réseaux,
         contenus, email » se lisait par-dessus le logo. Le détail vit dans
         la légende, où il a la place. */
      items: [
        { t: 'Web — sites, e-commerce, réservation, SEO' },
        { t: 'E-commerce & marketplaces' },
        { t: 'SaaS & IA — logiciels sur mesure' },
        { t: 'Acquisition — Google, Meta, Amazon Ads' },
        { t: 'Branding — identité, positionnement' },
        { t: 'Communication digitale' },
      ] },

    { l: 'list', bg: 'navy', kicker: '04 · Ce que nous avons construit',
      title: { ig: 'Des logiciels. Conçus, développés, mis en service.', li: 'Des logiciels. Conçus, développés, mis en service.' },
      size: 'd-md',
      items: [
        { t: 'CARGIO', s: 'Pilotage supply chain : achats, fournisseurs, transport' },
        { t: 'TRACKNPROFIT', s: 'Cockpit financier pour vendeurs multi-marketplaces' },
        { t: 'INZO', s: 'Gestion locative, du bail à la quittance' },
        { t: 'MYMONEYPILOT', s: 'Pilotage des finances personnelles' },
      ] },

    { l: 'list', kicker: '04 · Ce que nous avons construit',
      title: 'Des marques. Créées, lancées, distribuées.',
      size: 'd-md',
      items: [
        { t: 'SOUNDSWEALTH', s: 'High-tech : site en propre et marketplaces françaises' },
        { t: 'WELLKITCH', s: 'Loisirs créatifs : marque, site, distribution Amazon' },
        { t: 'ESLAY', s: 'Beauté et soins personnels' },
      ] },

    { l: 'point', bg: 'navy', kicker: '05 · Et pour nos clients',
      title: { ig: 'Ce qu’on construit pour nous, on le construit pour *toi*.', li: 'Ce que nous construisons pour nous, nous le construisons pour *vous*.' },
      body: { ig: 'BUSINESSWIN, cabinet de conseil en développement commercial : conception du site, architecture de l’information, présence digitale.', li: 'BUSINESSWIN, cabinet de conseil en développement commercial : conception du site, architecture de l’information, présence digitale.' },
      size: 'd-md' },

    { l: 'vs', kicker: '06 · La différence',
      title: { ig: 'Pourquoi ça change quelque chose pour toi.', li: 'Pourquoi cela change quelque chose pour vous.' },
      size: 'd-md',
      bad: { h: { ig: 'Ce qu’on entend souvent', li: 'Ce que l’on entend souvent' }, r: [
        'Des recommandations jamais éprouvées',
        { ig: 'Cinq prestataires qui ne se parlent pas', li: 'Cinq prestataires qui ne se parlent pas' },
        { ig: 'Un site livré, puis plus personne', li: 'Un site livré, puis plus personne' },
      ] },
      good: { h: 'WELLWISH', r: [
        { ig: 'Des méthodes qu’on applique à nos propres ventes', li: 'Des méthodes appliquées à nos propres ventes' },
        { ig: 'Une seule équipe, du design au déploiement', li: 'Une seule équipe, du design au déploiement' },
        { ig: 'Des outils qu’on fait vivre, pas qu’on livre', li: 'Des outils que nous faisons vivre, pas que nous livrons' },
      ] } },

    { l: 'cta', title: { ig: 'Et toi, qu’est-ce que tu veux *construire* ?', li: 'Et vous, que voulez-vous *construire* ?' },
      body: { ig: 'Dis-nous où tu en es. On te dit ce qui se construit, dans quel ordre.', li: 'Dites-nous où vous en êtes. Nous vous dirons ce qui se construit, et dans quel ordre.' },
      cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' } },
  ],
  cta: { ig: 'Parlons de ton projet', li: 'Parlons de votre projet' },
  captionIG: `On ne conseille pas depuis le bord du terrain. 🎯

QUI ON EST — une agence digitale & webmarketing qui construit aussi ses propres marques et ses propres logiciels. Ce qu'on te recommande, on se l'applique d'abord.

À QUI ON PARLE — entrepreneurs, TPE et PME, marques et e-commerçants, entreprises qui ont un process à outiller.

CE QU'ON FAIT — web, e-commerce et marketplaces, SaaS et IA, acquisition, branding, communication. Six expertises, une seule équipe.

CE QU'ON A CONSTRUIT —
· CARGIO, pilotage supply chain
· TRACKNPROFIT, cockpit financier multi-marketplaces
· INZO, gestion locative
· MYMONEYPILOT, finances personnelles
· SOUNDSWEALTH, WELLKITCH, ESLAY : trois marques créées, lancées, distribuées
· BUSINESSWIN : le site d'un cabinet de conseil

Swipe 👉 et dis-nous en commentaire ce que tu veux construire.`,
  textLI: `Nous ne conseillons pas depuis le bord du terrain.

QUI NOUS SOMMES
WELLWISH est une agence digitale & webmarketing qui construit également ses propres marques et ses propres logiciels. Ce que nous recommandons à nos clients, nous nous l'appliquons d'abord.

À QUI NOUS NOUS ADRESSONS
Entrepreneurs et indépendants qui lancent une activité. TPE et PME qui veulent vendre davantage sans multiplier les prestataires. Marques et e-commerçants qui veulent leurs propres canaux. Entreprises dont le métier ne rentre pas dans un logiciel du marché.

CE QUE NOUS FAISONS
Développement web · e-commerce et marketplaces · SaaS et intelligence artificielle · acquisition · branding · communication digitale. Six expertises réunies dans une même équipe.

CE QUE NOUS AVONS CONSTRUIT
Des logiciels : CARGIO (pilotage supply chain), TracknProfit (cockpit financier pour vendeurs multi-marketplaces), INZO (gestion locative), MyMoneyPilot (finances personnelles).
Des marques : SOUNDSWEALTH, WELLKITCH, ESLAY — créées, lancées et distribuées en propre et sur les marketplaces.
Pour nos clients : BUSINESSWIN, cabinet de conseil en développement commercial — conception du site, architecture de l'information, présence digitale.

La différence tient en une phrase : nous faisons vivre ce que nous construisons.

Parlons de votre projet : wellwish.fr/contact`,
  tags: tags('id') },
];

// Calendrier : 10 semaines × 3 (mardi · mercredi · jeudi), début lundi 30/11/2026.
// Semaines de Noël et du Nouvel An avancées au lundi-mercredi (24 et 31 déc. évités).
const DATES = [
  '2026-12-01','2026-12-02','2026-12-03', '2026-12-08','2026-12-09','2026-12-10',
  '2026-12-15','2026-12-16','2026-12-17', '2026-12-21','2026-12-22','2026-12-23',
  '2026-12-28','2026-12-29','2026-12-30', '2027-01-05','2027-01-06','2027-01-07',
  '2027-01-12','2027-01-13','2027-01-14', '2027-01-19','2027-01-20','2027-01-21',
  '2027-01-26','2027-01-27','2027-01-28', '2027-02-02','2027-02-03','2027-02-04',
  '2027-02-09',
];
const HOURS = { ig: '12 h 30', li: '8 h 30' };
CONTENTS.forEach((c, i) => {
  c.n = i + 1; c.week = Math.floor(i / 3) + 1; c.date = DATES[i]; c.hours = HOURS;
  c.audience = AUD; c.status = 'Prêt à publier — validation Filipe';
  c.platformFormat = c.format === 'Carrousel' ? { ig: 'Carrousel 1080×1350 (PNG)', li: 'Document PDF 1080×1350' }
    : c.format === 'Vidéo' ? { ig: 'Reel 1080×1920 (MP4) + couverture', li: 'Vidéo 1080×1350 (MP4)' }
    : { ig: 'Post 1080×1350 (PNG)', li: 'Post 1080×1350 (PNG)' };
});
