// WELLWISH — gabarits réutilisables (carrousels, statiques, couvertures).
// Chaque champ texte accepte une chaîne neutre ou {ig, li} (tutoiement / vouvoiement).
import fs from 'node:fs';
import path from 'node:path';
const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const svg = f => fs.readFileSync(path.join(ROOT, 'assets/logo', f), 'utf8');

export const LOGO = {
  light: svg('WELLWISH_logo-horizontal_gradient.svg').replace('id="wwg"', 'id="lg1"').replace('url(#wwg)', 'url(#lg1)'),
  dark: svg('WELLWISH_logo-horizontal_gradient.svg').replace('id="wwg"', 'id="lg2"').replace('url(#wwg)', 'url(#lg2)').replace('#12152B', '#FFFFFF'),
  sym: svg('WELLWISH_symbole_gradient.svg'),
};
const W_D = JSON.parse(fs.readFileSync(path.join(ROOT, 'assets/W.json'), 'utf8'));
export const wShape = (id = 'wg', op = 1) =>
  `<svg viewBox="0 0 ${W_D.w} ${W_D.h}" style="width:100%;height:auto;display:block;opacity:${op}"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#315CFF"/><stop offset=".52" stop-color="#7C3AED"/><stop offset="1" stop-color="#D946EF"/></linearGradient></defs><path d="${W_D.d}" fill="url(#${id})"/></svg>`;

export const I = {
  arrow: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>`,
  check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>`,
  x: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M7 7l10 10M17 7L7 17"/></svg>`,
  cart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2l2.4 11h10.2L20 8H6.2"/><circle cx="9" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/></svg>`,
  db: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3"/></svg>`,
  doc: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 13h6M10 17h6"/></svg>`,
  mail: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>`,
  bolt: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M13 2L4 14h7l-1 8 9-12h-7z"/></svg>`,
  user: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg>`,
  chart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>`,
  spark: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3l2.2 5.8L20 11l-5.8 2.2L12 19l-2.2-5.8L4 11l5.8-2.2z"/></svg>`,
  eye: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>`,
  card: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>`,
  cal: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>`,
  box: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/></svg>`,
  target: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/></svg>`,
  layers: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/></svg>`,
  code: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 7l-5 5 5 5M16 7l5 5-5 5"/></svg>`,
  pen: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M4 20l4-1L19 8l-3-3L5 16z"/></svg>`,
};

export const pick = (v, lang) => (v && typeof v === 'object' && !Array.isArray(v)) ? (v[lang] ?? v.ig) : v;
// *mot* -> mot en dégradé (1 par titre) ; \n -> saut de ligne ; espaces insécables FR
export const fmt = (s = '') => String(s)
  .replace(/ ([?!:;»])/g, '\u00A0$1').replace(/« /g, '«\u00A0')
  .replace(/\*(.+?)\*/g, '<span class="g">$1</span>').replace(/\n/g, '<br>');
const T = (v, lang) => fmt(pick(v, lang));

/* ------------------------------------------------------------------ mockups */
export function mock(m, lang = 'ig', dark = false) {
  const k = m.type;
  if (k === 'site-old') return `<div class="browser" style="filter:grayscale(.85) contrast(.9)"><div class="bar"><i></i><i></i><i></i><div class="url">votre-site.fr</div></div><div class="vp" style="height:${m.h||520}px;background:#F1F0EC">
    <div style="display:flex;justify-content:space-between"><div class="sk" style="width:180px;height:34px;background:#B9B6AA"></div><div style="display:flex;gap:10px">${'<div class="sk" style="width:80px;height:18px;background:#CFCBBF"></div>'.repeat(5)}</div></div>
    <div class="sk" style="margin-top:28px;height:150px;background:#D8D4C6"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-top:20px">${'<div><div class="sk" style="height:90px;background:#DEDBD0"></div><div class="sk" style="height:12px;margin-top:10px;background:#D2CEC2"></div><div class="sk" style="height:12px;width:70%;margin-top:8px;background:#D2CEC2"></div></div>'.repeat(3)}</div>
    <div class="sk" style="margin-top:20px;height:12px;background:#D2CEC2"></div><div class="sk" style="margin-top:8px;height:12px;width:80%;background:#D2CEC2"></div></div></div>`;
  if (k === 'site-new') return `<div class="browser"><div class="bar"><i></i><i></i><i></i><div class="url">votre-site.fr</div></div><div class="vp" style="height:${m.h||520}px;background:var(--navy);color:#fff;overflow:hidden">
    <div style="display:flex;justify-content:space-between;align-items:center"><div style="font:800 26px var(--f-d)">Votre marque</div><div style="display:flex;gap:18px;align-items:center">${'<div class="sk" style="width:60px;height:12px;background:rgba(255,255,255,.25)"></div>'.repeat(3)}<div style="padding:10px 18px;border-radius:99px;background:var(--grad);font:600 16px var(--f-t)">Demander un devis</div></div></div>
    <div style="margin-top:46px;font:800 54px/1 var(--f-d);letter-spacing:-.03em;max-width:80%">Une promesse <span class="g">claire.</span></div>
    <div class="sk" style="margin-top:18px;height:14px;width:60%;background:rgba(255,255,255,.3)"></div>
    <div style="display:flex;gap:12px;margin-top:24px"><div style="padding:14px 24px;border-radius:99px;background:var(--grad);font:600 18px var(--f-t)">Réserver →</div><div style="padding:14px 24px;border-radius:99px;border:2px solid rgba(255,255,255,.3);font:500 18px var(--f-t)">Voir les offres</div></div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-top:34px">${['★ Avis clients','✓ Paiement sécurisé','⚡ Réponse rapide'].map(t=>`<div style="border:2px solid rgba(255,255,255,.14);border-radius:14px;padding:14px;font:500 16px var(--f-t)">${t}</div>`).join('')}</div></div></div>`;
  if (k === 'dash') return `<div class="dash" style="height:${m.h||600}px"><div class="side"><div style="width:44px;height:44px">${wShape('dw'+(m.id||''))}</div>${'<div class="sk" style="height:12px;background:rgba(255,255,255,.18)"></div>'.repeat(5)}</div>
    <div class="main"><div style="display:flex;justify-content:space-between;align-items:center"><div style="font:800 30px var(--f-d)">${m.title||'Pilotage'}</div><div class="tag concept" style="font-size:14px;padding:8px 14px">Données fictives</div></div>
    <div style="display:grid;grid-template-columns:repeat(${(m.kpis||['ROAS','CPA','Conversion']).length},1fr);gap:14px">${(m.kpis||['ROAS','CPA','Conversion']).map((x,i)=>`<div class="kpi"><div class="lb">${x}</div><div class="sk ${i===0?'gr':'l'}" style="height:26px;width:${60+i*10}%;margin-top:14px"></div></div>`).join('')}</div>
    <div class="kpi" style="flex:1;display:flex;flex-direction:column;justify-content:flex-end"><div class="bars" style="height:100%">${[34,48,40,58,52,70,64,82,76,92].map((h,i)=>`<i class="${i>6?'on':''}" style="height:${h}%"></i>`).join('')}</div></div></div></div>`;
  if (k === 'flow') return `<div style="display:flex;flex-direction:column;gap:14px">${m.nodes.map((n,i)=>`${i?`<div style="height:34px;margin-left:51px;border-left:3px dashed ${dark?'rgba(185,166,255,.5)':'rgba(124,58,237,.4)'}"></div>`:''}<div class="node"><div class="ic">${I[n.i]||I.bolt}</div><div style="flex:1">${pick(n.t,lang)}</div>${n.auto?`<div class="chip">Auto</div>`:''}</div>`).join('')}</div>`;
  if (k === 'chat') return `<div class="card" style="display:flex;flex-direction:column;gap:20px;padding:34px">
    <div style="display:flex;align-items:center;gap:14px;padding-bottom:18px;border-bottom:2px solid ${dark?'var(--line-d)':'var(--line)'}"><div style="width:54px;height:54px;border-radius:16px;background:var(--grad);display:grid;place-items:center;color:#fff"><div style="width:30px;height:30px">${I.spark}</div></div><div><div style="font:700 28px var(--f-t)">${m.name||'Assistant IA'}</div><div class="mono sm" style="color:var(--muted);margin-top:6px;font-size:15px">Concept illustratif</div></div></div>
    ${m.msgs.map(x=>`<div class="bubble ${x.u?'u':'a'}">${pick(x.t,lang)}</div>`).join('')}</div>`;
  if (k === 'phone-shop') return `<div class="phone"><div class="scr">
    <div class="sk" style="height:300px;border-radius:24px;background:linear-gradient(140deg,#E6E1FA,#F7F4FF)"></div>
    <div style="font:800 30px/1.1 var(--f-d);margin-top:20px">Votre produit</div>
    <div style="font:500 18px var(--f-t);color:var(--muted);margin-top:8px">★★★★★ · Avis vérifiés</div>
    <div class="sk" style="height:10px;margin-top:16px"></div><div class="sk" style="height:10px;width:70%;margin-top:8px"></div>
    <div style="display:flex;gap:8px;margin-top:18px">${'<div style="width:46px;height:46px;border-radius:12px;border:2px solid var(--line)"></div>'.repeat(3)}</div>
    <div style="position:absolute;left:22px;right:22px;bottom:26px;padding:20px;border-radius:99px;background:var(--grad);color:#fff;text-align:center;font:600 22px var(--f-t)">Ajouter au panier</div></div></div>`;
  if (k === 'tools') { const ns = m.items || ['CRM','Devis','Factures','Stock','Agenda','Emails','Tableurs','Messagerie','Planning','Notes'];
    return `<div style="position:relative;height:${m.h||560}px">${ns.map((n,i)=>{const a=i/ns.length*Math.PI*2, r=m.r||230, x=50+Math.cos(a)*40, y=50+Math.sin(a)*41;return `<div class="node" style="position:absolute;left:${x}%;top:${y}%;transform:translate(-50%,-50%) rotate(${(i%3-1)*4}deg);font-size:24px;padding:16px 20px">${n}</div>`}).join('')}
    ${m.hub?`<div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:210px;height:210px;border-radius:50%;background:var(--navy);display:grid;place-items:center;box-shadow:0 0 0 18px rgba(124,58,237,.12)"><div style="width:120px">${wShape('th')}</div></div>`:''}</div>`; }
  if (k === 'funnel') return `<div style="display:flex;flex-direction:column;gap:14px;align-items:center">${m.steps.map((s,i)=>`<div style="width:${100-i*15}%;padding:26px 30px;border-radius:20px;background:${i===m.steps.length-1?'var(--grad)':(dark?'var(--navy2)':'#fff')};color:${i===m.steps.length-1||dark?'#fff':'var(--ink)'};border:2px solid ${dark?'var(--line-d)':'var(--line)'};display:flex;justify-content:space-between;align-items:center;font:600 30px var(--f-t)"><span>${pick(s,lang)}</span>${m.leak&&m.leak[i]?`<span class="mono sm" style="color:${dark?'#FF8E7A':'#C23A22'};font-size:17px">${pick(m.leak[i],lang)}</span>`:''}</div>`).join('')}</div>`;
  if (k === 'brand') return `<div class="card" style="padding:36px;display:grid;grid-template-columns:1fr 1fr;gap:22px">
    <div style="grid-column:1/3;display:flex;align-items:center;gap:20px"><div style="width:84px;height:84px;border-radius:22px;background:var(--navy);display:grid;place-items:center"><div style="width:52px;height:52px;border-radius:50%;border:8px solid #fff;border-right-color:transparent"></div></div><div><div style="font:800 40px var(--f-d)">Votre marque</div><div class="mono sm" style="color:var(--muted);font-size:16px;margin-top:8px">Concept illustratif</div></div></div>
    <div><div class="mono sm" style="font-size:15px;color:var(--muted)">Couleurs</div><div style="display:flex;gap:8px;margin-top:12px">${['#12152B','#315CFF','#7C3AED','#F2EEFF'].map(c=>`<div style="flex:1;height:70px;border-radius:12px;background:${c};border:2px solid var(--line)"></div>`).join('')}</div></div>
    <div><div class="mono sm" style="font-size:15px;color:var(--muted)">Typographie</div><div style="font:800 64px/1 var(--f-d);margin-top:10px">Aa</div></div>
    <div style="grid-column:1/3"><div class="mono sm" style="font-size:15px;color:var(--muted)">Déclinaisons</div><div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:12px">${['Site','Réseaux','Packaging','Print'].map((t,i)=>`<div style="height:86px;border-radius:12px;background:${['var(--lavender)','var(--navy)','#fff','var(--lavender)'][i]};border:2px solid var(--line);display:grid;place-items:center;font:500 18px var(--f-t);color:${i===1?'#fff':'var(--ink)'}">${t}</div>`).join('')}</div></div></div>`;
  if (k === 'channels') return `<div style="display:grid;grid-template-columns:1fr 1fr;gap:18px">${m.items.map(c=>`<div class="node" style="font-size:30px"><div class="ic">${I[c.i]||I.target}</div>${c.t}</div>`).join('')}</div>`;
  if (k === 'loop') return `<div style="position:relative;width:700px;height:700px;margin:0 auto"><div style="position:absolute;inset:60px;border-radius:50%;border:3px dashed ${dark?'rgba(185,166,255,.45)':'rgba(124,58,237,.35)'}"></div>
    ${m.steps.map((s,i)=>{const a=-Math.PI/2+i/m.steps.length*Math.PI*2;return `<div class="node" style="position:absolute;left:${50+Math.cos(a)*41}%;top:${50+Math.sin(a)*41}%;transform:translate(-50%,-50%);font-size:24px;padding:16px 20px;white-space:nowrap"><div class="ic" style="width:40px;height:40px">${I[s.i]||I.bolt}</div>${pick(s.t,lang)}</div>`}).join('')}
    <div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:150px">${wShape('lp')}</div></div>`;
  return '';
}

/* ------------------------------------------------------------------ cadres */
function deco(d, dark) {
  if (!d) return '';
  if (d === 'orb') return `<div class="orb" style="width:840px;height:840px;right:-420px;bottom:-420px"></div>`;
  if (d === 'orb-tl') return `<div class="orb" style="width:520px;height:520px;right:-260px;top:-260px"></div>`;
  if (d === 'w') return `<div class="wcrop" style="width:900px;right:-330px;bottom:-140px">${wShape('dw1', dark?1:.95)}</div>${dark?'<div class="halo" style="width:900px;height:900px;right:-200px;bottom:-300px"></div>':''}`;
  if (d === 'grid') return dark ? '<div class="grid-d"></div><div class="halo" style="width:1000px;height:1000px;right:-300px;top:-300px"></div>' : '<div class="grid-l"></div>';
  return '';
}
const arrowTxt = (lang) => lang === 'li' ? 'Faites défiler' : 'Glisse';

export function frame({ bg = 'white', cls = '', i, n, inner, deco: d, logoTop = false, lang, story = false }) {
  const dark = bg === 'navy';
  const top = logoTop ? `<div class="hd"><div class="logo-h">${dark ? LOGO.dark : LOGO.light}</div>${n ? `<div class="ctr">${String(i).padStart(2,'0')} / ${String(n).padStart(2,'0')}</div>` : ''}</div>` : '';
  const foot = !logoTop ? `<div class="ft"><div class="logo-s">${dark ? LOGO.dark : LOGO.light}</div>${n ? `<div class="ctr">${String(i).padStart(2,'0')} / ${String(n).padStart(2,'0')}</div>` : ''}</div>` : '';
  const prog = n ? `<div class="progress"><i style="width:${(i / n) * 100}%"></i></div>` : '';
  return `<div class="frame ${story ? 'story' : ''} bg-${bg} ${cls}">${deco(d, dark)}${top}${inner}${foot}${prog}</div>`;
}

/* ------------------------------------------------------------------ slides */
export function slide(s, ctx) {
  const { lang, i, n } = ctx; const dark = s.bg === 'navy';
  const kicker = s.kicker ? `<div class="mono k-violet" style="margin-bottom:34px">${T(s.kicker, lang)}</div>` : '';
  const concept = s.concept ? `<div style="margin-top:28px"><span class="tag concept">${lang==='li'?'Exemple illustratif':'Exemple illustratif'}</span></div>` : '';
  let inner = '';
  switch (s.l) {
    case 'cover': {
      inner = `<div class="body-zone" style="justify-content:${s.v?'flex-start':'center'};${s.v?'top:220px':''}">${kicker}
        ${s.big ? `<div class="bracket" style="margin-bottom:24px">[${s.big}]</div>` : ''}
        <div class="${s.size||'d-xl'}" style="max-width:${s.mw||900}px">${T(s.title, lang)}</div>
        ${s.sub ? `<div class="lead" style="margin-top:36px;max-width:820px">${T(s.sub, lang)}</div>` : ''}
        ${s.v ? `<div style="margin-top:56px">${mock(s.v, lang, dark)}</div>` : ''}</div>
        <div style="position:absolute;left:var(--m);bottom:110px;z-index:5" class="swipe ${dark?'':''}">${arrowTxt(lang)} <span class="k-violet">${I.arrow}</span></div>`;
      return frame({ bg: s.bg || 'lav', i, n, inner, deco: s.deco ?? 'orb', logoTop: true, lang });
    }
    case 'point': {
      inner = `<div class="body-zone" style="top:150px;justify-content:${s.v?'flex-start':'center'}">
        ${s.num ? `<div class="bracket" style="font-size:${s.v?170:230}px">[${s.num}]</div>` : kicker}
        <div class="${s.size||(s.v?'d-md':'d-lg')}" style="margin-top:${s.num?40:0}px;max-width:920px">${T(s.title, lang)}</div>
        ${s.body ? `<div class="${s.v?'body':'lead'}" style="margin-top:36px;max-width:880px">${T(s.body, lang)}</div>` : ''}
        ${s.v ? `<div style="margin-top:auto;padding-top:40px">${mock(s.v, lang, dark)}</div>` : ''}${concept}</div>`;
      return frame({ bg: s.bg || 'white', i, n, inner, deco: s.deco, lang });
    }
    case 'statement': {
      inner = `<div class="body-zone">${kicker}<div class="${s.size||'d-lg'}">${T(s.title, lang)}</div>
        ${s.body ? `<div class="lead" style="margin-top:40px;max-width:860px">${T(s.body, lang)}</div>` : ''}</div>`;
      return frame({ bg: s.bg || 'navy', i, n, inner, deco: s.deco ?? (s.bg==='navy'||!s.bg?'grid':null), lang });
    }
    case 'list': {
      inner = `<div class="body-zone" style="top:150px">${kicker}
        <div class="${s.size||'d-md'}" style="margin-bottom:50px;max-width:900px">${T(s.title, lang)}</div>
        <div class="list">${s.items.map((it, k) => `<div class="it"><div class="n">${String(k+1).padStart(2,'0')}</div><div class="t">${T(it.t, lang)}</div>${it.s ? `<div class="s">${T(it.s, lang)}</div>` : ''}</div>`).join('')}</div></div>`;
      return frame({ bg: s.bg || 'white', i, n, inner, deco: s.deco, lang });
    }
    case 'vs': {
      const row = (r, good) => `<div class="row"><span style="color:${good?'var(--lilac)':'#C23A22'}">${good?I.check:I.x}</span><span>${T(r, lang)}</span></div>`;
      inner = `<div class="body-zone" style="top:150px">${kicker}
        <div class="${s.size||'d-md'}" style="margin-bottom:50px">${T(s.title, lang)}</div>
        <div class="vs"><div class="col bad"><div class="hdr">${T(s.bad.h, lang)}</div>${s.bad.r.map(r=>row(r,false)).join('')}</div>
        <div class="col good"><div class="hdr">${T(s.good.h, lang)}</div>${s.good.r.map(r=>row(r,true)).join('')}</div></div>${concept}</div>`;
      return frame({ bg: s.bg || 'white', i, n, inner, deco: s.deco, lang });
    }
    case 'visual': {
      inner = `<div class="body-zone" style="top:150px">${kicker}
        <div class="${s.size||'d-sm'}" style="max-width:900px">${T(s.title, lang)}</div>
        ${s.body ? `<div class="body" style="margin-top:22px;max-width:880px">${T(s.body, lang)}</div>` : ''}
        <div style="margin-top:56px">${mock(s.v, lang, dark)}</div>${concept}</div>`;
      return frame({ bg: s.bg || 'white', i, n, inner, deco: s.deco, lang });
    }
    case 'cta': {
      inner = `<div class="body-zone" style="justify-content:center">${kicker}
        <div class="${s.size||'d-lg'}" style="max-width:880px">${T(s.title, lang)}</div>
        ${s.body ? `<div class="lead" style="margin-top:34px;max-width:800px">${T(s.body, lang)}</div>` : ''}
        <div style="margin-top:60px"><span class="cta-pill">${T(s.cta || 'wellwish.fr', lang)} ${I.arrow}</span></div>
        <div class="mono sm" style="margin-top:34px;color:rgba(255,255,255,.55)">wellwish.fr/contact</div></div>`;
      return frame({ bg: 'navy', i, n, inner, deco: 'w', logoTop: true, lang });
    }
  }
  throw new Error('layout inconnu ' + s.l);
}

export function page(body, w = 1080, h = 1350) {
  return `<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="ds.css"><style>html,body{width:${w}px;height:${h}px;overflow:hidden}</style></head><body>${body}</body></html>`;
}
