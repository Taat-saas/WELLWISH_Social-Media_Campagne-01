// WELLWISH — 10 vidéos motion design. Une scène = durée + HTML animé + notes de storyboard.
import fs from 'node:fs';
import path from 'node:path';
import { LOGO, I, mock, pick, fmt } from './tpl.mjs';
const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const W = JSON.parse(fs.readFileSync(path.join(ROOT, 'assets/W.json'), 'utf8'));
const BANDS = W.d.split('M').filter(Boolean).map(p => 'M' + p);

// --- primitives
const A = (html, o = {}) => `<${o.tag || 'div'} class="a ${o.cls || ''}" style="--an:${o.an || 'up'};--d:${o.d || 0}s;${o.du ? `--du:${o.du}s;` : ''}${o.st || ''}">${html}</${o.tag || 'div'}>`;
const tx = (v, L) => fmt(pick(v, L));
const tag = (L) => `<div class="vtag">${A(`<span class="tag concept" style="background:rgba(255,255,255,.08);color:rgba(255,255,255,.8);border-color:rgba(255,255,255,.2)">Exemple illustratif</span>`, { an: 'fade', d: .6 })}</div>`;
const tagL = () => `<div class="vtag">${A(`<span class="tag concept">Exemple illustratif</span>`, { an: 'fade', d: .6 })}</div>`;
const logo = (dark = true) => `<div class="vlogo">${A(dark ? LOGO.dark : LOGO.light, { an: 'fade', d: 0 })}</div>`;
const bg = (k) => k === 'grid' ? `<div class="grid-d"></div><div class="halo hold" style="width:1200px;height:1200px;right:-400px;top:-300px;--an:drift;--du:8s"></div>` : '';

function title({ k, lines, sub, size = '', start = .15, step = .22, an = 'wipeup' }) {
  return (k ? A(`<div class="vk">${k}</div>`, { an: 'fade', d: start - .1 }) : '') +
    `<div class="vt ${size}">${lines.map((l, i) => A(l, { an, d: start + i * step, du: .9 })).join('')}</div>` +
    (sub ? A(`<div class="vs2">${sub}</div>`, { d: start + lines.length * step + .2 }) : '');
}
const S = (d, cls, html, sb) => ({ d, cls, html, sb });

// Carte de fin : le symbole se construit bande par bande, puis le mot-symbole et le CTA.
function endCard(cta, extra = '') {
  return S(5.5, 'dark last', L => `${bg('grid')}
    <div style="display:flex;flex-direction:column;align-items:flex-start">
      <svg viewBox="0 0 ${W.w} ${W.h}" style="width:360px;overflow:visible"><defs><linearGradient id="eg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#315CFF"/><stop offset=".52" stop-color="#7C3AED"/><stop offset="1" stop-color="#D946EF"/></linearGradient></defs>
      ${BANDS.map((b, i) => `<path class="a" style="--an:wipeup;--d:${.1 + i * .16}s;--du:.7s" d="${b}" fill="url(#eg)"/>`).join('')}</svg>
      ${A(`<div style="font:700 54px/1 var(--f-t);letter-spacing:.14em;margin-top:56px">WELLWISH</div>`, { an: 'fade', d: .7 })}
      ${extra ? A(`<div class="vs2" style="margin-top:44px">${extra}</div>`, { d: .9 }) : ''}
      ${A(`<span class="cta-pill" style="margin-top:70px">${tx(cta, L)} ${I.arrow}</span>`, { an: 'pop', d: 1.1 })}
      ${A(`<div class="mono sm" style="margin-top:36px;color:rgba(255,255,255,.55)">wellwish.fr</div>`, { an: 'fade', d: 1.4 })}
    </div>`, { vis: 'Carte de fin navy + grille. Le symbole W se construit bande par bande, mot WELLWISH, bouton CTA.', mv: 'Révélation par masque vertical des 3 bandes (décalage 0,16 s), pop du CTA.' });
}
const ok = `<span class="ok">${I.check}</span>`;
const vnode = (ic, t, o = {}) => `<div class="vnode">${`<div class="ic">${I[ic]}</div>`}<span>${t}</span>${o.ok ? A(ok, { an: 'pop', d: o.okd || 0 }) : ''}</div>`;

export const VIDEOS = {
/* --------------------------------------------------------------- P01 */
P01: { vo: 'Une idée. Un projet. Un blocage. Chez WELLWISH, on transforme l’idée en solution, et la solution en performance. Web, e-commerce, logiciels, intelligence artificielle, acquisition, branding : une seule équipe, de la réflexion au déploiement. WELLWISH.',
  sound: 'Nappe électronique minimaliste 100–110 BPM. Impact grave sur chaque mot en dégradé. « Whoosh » doux sur le ruban. Montée finale + silence d’une demi-seconde avant le logo.',
  scenes: [
  S(3.4, 'dark', L => bg('grid') + logo() + title({ k: 'Manifeste', lines: ['De l’idée', 'à la <span class="g">solution.</span>'], size: 'xl' }), { vis: 'Navy + grille technique, halo violet qui dérive.', mv: 'Titre révélé ligne à ligne par masque montant.' }),
  S(3.2, 'dark', L => bg('grid') + logo() + title({ lines: ['De la solution', 'à la <span class="g">performance.</span>'], size: 'xl' }), { vis: 'Même décor, continuité.', mv: 'Fondu enchaîné, masque montant.' }),
  S(4.6, 'dark', L => `<div style="margin:0 -90px;display:flex;flex-direction:column;gap:40px">
      <div class="ticker hold" style="--an:tick;--du:9s">${('<span>Web</span><span class="o">E\u2011commerce</span><span>SaaS</span><span class="o">IA</span><span>Ads</span><span class="o">Branding</span>').repeat(2)}</div>
      <div class="ticker hold" style="--an:tick;--du:12s;animation-direction:reverse">${('<span class="o">Marketplaces</span><span>Automatisation</span><span class="o">SEO</span><span>Contenus</span>').repeat(2)}</div>
      <div class="ticker hold" style="--an:tick;--du:10s">${('<span>UX/UI</span><span class="o">Data</span><span>Shopify</span><span class="o">Logiciels</span>').repeat(2)}</div></div>`,
    { vis: 'Trois rubans typographiques des expertises, alternance plein / contour.', mv: 'Défilement horizontal continu, vitesses différentes (parallaxe).' }),
  S(5, 'light', L => title({ k: 'Une seule équipe', lines: ['Tech.', 'Marketing.', '<span class="g">E\u2011commerce.</span>'], size: 'xl', step: .35 }) +
    `<div style="display:flex;gap:16px;margin-top:56px;flex-wrap:wrap">${['De la réflexion', 'au déploiement'].map((t, i) => A(`<span class="chip" style="font-size:26px;padding:16px 22px">${t}</span>`, { an: 'pop', d: 1.4 + i * .2 })).join('')}</div>`,
    { vis: 'Bascule en lavande. Trois mots empilés, le dernier en dégradé.', mv: 'Apparition rythmée sur le tempo (0,35 s), pastilles en pop.' }),
  S(4.4, 'dark', L => bg('grid') + title({ lines: ['On ne vend pas des sites.'], size: 'md' }) + A(`<div class="vt" style="margin-top:30px">${L === 'li' ? 'Nous construisons ce qui fait <span class="g">avancer</span> votre activité.' : 'On construit ce qui fait <span class="g">avancer</span> ton activité.'}</div>`, { an: 'blurin', d: .9, du: 1 }),
    { vis: 'Navy. Phrase de rupture puis promesse.', mv: 'Première ligne en masque, seconde en flou → net.' }),
  endCard({ ig: 'Parlons de ton projet', li: 'Parlons de votre projet' }),
]},
/* --------------------------------------------------------------- S01 */
S01: { vo: 'Et si votre prochain collaborateur était une IA ? Branché sur vos outils, il prépare un devis, rédige les relances, met à jour le CRM. Vous validez. Il exécute.',
  sound: 'Pulsation tech légère. Son « message » discret à chaque bulle, « tick » à chaque validation. Pas de musique épique.',
  scenes: [
  S(3.6, 'dark', L => bg('grid') + logo() + title({ k: 'IA · Assistant métier', lines: L === 'li' ? ['Et si votre', 'prochain collaborateur', 'était une <span class="g">IA</span> ?'] : ['Et si ton', 'prochain collaborateur', 'était une <span class="g">IA</span> ?'], size: 'md' }), { vis: 'Navy + grille, accroche.', mv: 'Masque montant ligne à ligne.' }),
  S(8.2, 'dark', L => `<div style="display:flex;flex-direction:column;gap:26px">
     ${A(`<div style="display:flex;align-items:center;gap:18px;padding-bottom:26px;border-bottom:2px solid var(--line-d)"><div style="width:72px;height:72px;border-radius:20px;background:var(--grad);display:grid;place-items:center"><div style="width:40px;height:40px">${I.spark}</div></div><div><div style="font:700 36px var(--f-t)">Assistant IA</div><div class="mono sm" style="color:rgba(255,255,255,.5);margin-top:8px">en ligne</div></div></div>`, { an: 'fade' })}
     ${A(`<div class="bubble u" style="font-size:36px;max-width:85%;margin-left:auto">Une demande de devis vient d’arriver. Tu peux t’en occuper ?</div>`, { an: 'right', d: .6 })}
     ${A(`<div class="bubble a" style="font-size:36px;max-width:85%;background:var(--navy2);border:2px solid var(--line-d)">C’est fait. Devis préparé à partir du catalogue, relance programmée dans 3 jours.</div>`, { an: 'left', d: 2.4 })}
     ${A(`<div class="bubble u" style="font-size:36px;max-width:85%;margin-left:auto">Parfait, envoie-le.</div>`, { an: 'right', d: 4.6 })}
     ${A(`<div class="bubble a" style="font-size:36px;background:var(--navy2);border:2px solid var(--line-d)">Envoyé ✓ CRM mis à jour.</div>`, { an: 'left', d: 5.8 })}</div>` + tag(L),
    { vis: 'Interface de chat d’assistant IA (concept), bulles lavande / navy.', mv: 'Bulles glissées gauche/droite au rythme d’une vraie conversation.' }),
  S(6.6, 'dark', L => A(`<div class="vk">Ce qu’il vient de faire</div>`, { an: 'fade' }) + `<div style="display:flex;flex-direction:column">
     ${[['doc', 'Devis préparé'], ['mail', 'Relance rédigée'], ['db', 'CRM mis à jour']].map(([ic, t], i) => (i ? A('<div class="vconn"></div>', { an: 'barup', d: .5 + i * .9 - .3, du: .3 }) : '') + A(vnode(ic, t, { ok: true, okd: .9 + i * .9 }), { an: 'left', d: .3 + i * .9 })).join('')}</div>` + tag(L),
    { vis: 'Trois actions en nœuds reliés, coche dégradée sur chacune.', mv: 'Nœuds glissés depuis la gauche, connecteurs qui se tracent, coches en pop.' }),
  S(3.8, 'light', L => title({ lines: L === 'li' ? ['Vous validez.', 'L’IA <span class="g">exécute.</span>'] : ['Toi, tu valides.', 'Lui, il <span class="g">exécute.</span>'], size: 'xl', step: .5 }), { vis: 'Lavande, punchline.', mv: 'Deux temps marqués (0,5 s).' }),
  endCard({ ig: 'Construisons ton assistant', li: 'Construisons votre prochaine solution' }),
]},
/* --------------------------------------------------------------- W02 */
W02: { vo: 'Un beau site qui ne convertit pas reste un mauvais investissement. Une promesse claire, un appel à l’action visible, de la réassurance, de la vitesse. Beau, et efficace.',
  sound: 'Rythme pop-électro léger. Son « glitch » sur l’ancien site, « swoosh » lumineux à la transformation, « pop » sur chaque annotation.',
  scenes: [
  S(3.8, 'white', L => logo(false) + title({ k: 'Web · Conversion', lines: ['Un beau site', 'qui ne convertit pas', '= un mauvais <span class="g">investissement.</span>'], size: 'md' }), { vis: 'Fond blanc chaud, accroche.', mv: 'Masque montant ligne à ligne.' }),
  S(5, 'white', L => A(`<div class="vk">Avant</div>`, { an: 'fade' }) + `<div class="mkw" style="position:relative">${A(`<div class="mk">${mock({ type: 'site-old', h: 620 })}</div>`, { an: 'zoomin' })}
     ${A(`<div class="callout" style="position:static"><i style="background:#C23A22"></i>Promesse floue</div>`, { an: 'pop', d: 1.4, st: `position:absolute;left:40px;top:180px;z-index:6` })}
     ${A(`<div class="callout" style="position:static"><i style="background:#C23A22"></i>Aucun appel à l’action</div>`, { an: 'pop', d: 2.2, st: `position:absolute;right:30px;top:420px;z-index:6` })}
     ${A(`<div class="callout" style="position:static"><i style="background:#C23A22"></i>Lent sur mobile</div>`, { an: 'pop', d: 3, st: `position:absolute;left:120px;bottom:40px;z-index:6` })}</div>` + tagL(),
    { vis: 'Mockup navigateur d’un site vieillissant, désaturé (concept).', mv: 'Zoom arrière d’entrée, annotations corail en pop successif.' }),
  S(8.4, 'dark', L => A(`<div class="vk">Après</div>`, { an: 'fade' }) + `<div class="mkw" style="position:relative">${A(`<div class="mk">${mock({ type: 'site-new', h: 620 })}</div>`, { an: 'blurin', du: 1 })}
     ${[['Promesse claire', 'left:20px;top:150px'], ['Appel à l’action visible', 'right:10px;top:330px'], ['Réassurance', 'left:60px;bottom:110px'], ['Rapide sur mobile', 'right:40px;bottom:10px']].map(([t, p], i) => A(`<div class="callout" style="position:static"><i></i>${t}</div>`, { an: 'pop', d: 1.4 + i * 1.1, st: `position:absolute;${p};z-index:6` })).join('')}</div>` + tag(L),
    { vis: 'Le même site transformé : navy, promesse forte, CTA dégradé, bandeau de réassurance (concept).', mv: 'Transition flou → net, 4 annotations en pop toutes les 1,1 s.' }),
  S(4, 'light', L => title({ lines: ['Beau <span class="g">et</span> efficace.', 'C’est le minimum.'], size: 'xl', step: .5 }), { vis: 'Lavande, punchline.', mv: 'Deux temps.' }),
  endCard({ ig: 'Parlons de ton site', li: 'Parlons de votre projet' }),
]},
/* --------------------------------------------------------------- E02 */
E02: { vo: 'Votre boutique en ligne doit être votre meilleur vendeur. Elle accueille, elle répond, elle rassure, elle conclut. Vingt-quatre heures sur vingt-quatre.',
  sound: 'Groove léger et positif. « Tap » à chaque annotation, son de caisse enregistreuse stylisé (très court) à la confirmation.',
  scenes: [
  S(3.8, 'dark', L => bg('grid') + logo() + title({ k: 'E-commerce', lines: L === 'li' ? ['Votre boutique', 'doit être votre', 'meilleur <span class="g">vendeur.</span>'] : ['Ta boutique', 'doit être ton', 'meilleur <span class="g">vendeur.</span>'], size: 'xl' }), { vis: 'Navy, accroche XL.', mv: 'Masque montant.' }),
  S(9.6, 'light', L => `<div style="position:relative;display:flex;justify-content:center">${A(`<div class="mk" style="zoom:1.25">${mock({ type: 'phone-shop' })}</div>`, { an: 'up', du: 1 })}
     ${[['Fiche produit claire', 'left:-20px;top:12%'], ['Avis visibles', 'right:-20px;top:34%'], ['Livraison annoncée', 'left:-10px;top:58%'], ['Paiement en 2 clics', 'right:-10px;top:80%']].map(([t, p], i) => A(`<div class="callout" style="position:static"><i></i>${t}</div>`, { an: 'pop', d: 1.3 + i * 1.2, st: `position:absolute;${p};z-index:6` })).join('')}
     ${A(`<div><div style="padding:34px 44px;border-radius:30px;background:var(--navy);color:#fff;font:700 40px var(--f-t);display:flex;gap:18px;align-items:center;box-shadow:0 30px 80px rgba(18,21,43,.45)"><span style="width:56px;height:56px;border-radius:50%;background:var(--grad);display:grid;place-items:center"><span style="width:32px;height:32px;display:block">${I.check}</span></span>Commande confirmée</div></div>`, { an: 'pop', d: 6.6, st: 'position:absolute;left:12%;top:42%;z-index:8' })}</div>` + tagL(),
    { vis: 'Smartphone avec fiche produit (concept), annotations autour, puis carte « Commande confirmée ».', mv: 'Montée du téléphone, 4 annotations alternées gauche/droite, pop final.' }),
  S(6, 'dark', L => A(`<div class="vk">Comme un bon vendeur</div>`, { an: 'fade' }) + `<div class="vt">${['Elle accueille.', 'Elle répond.', 'Elle rassure.', 'Elle <span class="g">conclut.</span>'].map((t, i) => A(t, { an: 'wipeup', d: .3 + i * .55 })).join('')}</div>` + A(`<div class="vs2">24 h / 24, 7 j / 7.</div>`, { d: 2.8 }),
    { vis: 'Navy, quatre verbes empilés.', mv: 'Apparition sur le tempo (0,55 s).' }),
  endCard({ ig: 'Parlons de ta boutique', li: 'Parlons de votre boutique' }),
]},
/* --------------------------------------------------------------- M03 */
M03: { vo: 'Le digital n’est pas réservé aux grandes entreprises. Notre vision : en faire un accélérateur de croissance accessible à tous. Des solutions durables, évolutives, intelligentes. Qui grandissent avec vous.',
  sound: 'Piano + nappe ambient, tempo lent, sentiment d’ouverture (fin d’année). Pas de percussions avant la carte de fin.',
  scenes: [
  S(4.2, 'dark', L => bg('grid') + logo() + title({ k: 'Notre vision', lines: ['Le digital', 'n’est pas réservé', 'aux <span class="g">grandes</span>', 'entreprises.'], size: 'md', step: .3 }), { vis: 'Navy + grille.', mv: 'Masque montant lent (0,3 s).' }),
  S(4.4, 'light', L => title({ lines: ['Un accélérateur', 'de croissance', '<span class="g">accessible.</span>'], size: 'xl', step: .3, an: 'blurin' }) + A(`<div class="vs2">Quelle que soit la taille. Quelle que soit la maturité tech.</div>`, { d: 1.4 }), { vis: 'Lavande, promesse centrale.', mv: 'Flou → net, mot par mot.' }),
  S(5.4, 'dark', L => bg('grid') + `<div class="vt xl">${['Durable.', 'Évolutif.', '<span class="g">Intelligent.</span>'].map((t, i) => A(t, { an: 'left', d: .2 + i * 1.1, du: .7 })).join('')}</div>`, { vis: 'Trois adjectifs XL.', mv: 'Glissement depuis la gauche, un par mesure.' }),
  S(4, 'white', L => title({ lines: L === 'li' ? ['Des solutions qui', 'grandissent <span class="g">avec vous.</span>'] : ['Des solutions qui', 'grandissent <span class="g">avec toi.</span>'], size: 'md', step: .4 }), { vis: 'Blanc chaud, phrase de clôture.', mv: 'Masque montant.' }),
  endCard({ ig: 'Fais du digital un levier', li: 'Faites du digital un levier' }),
]},
/* --------------------------------------------------------------- C02 */
C02: { vo: 'Vos données sont partout. Sauf là où vous en avez besoin. Centralisées et synchronisées automatiquement, elles deviennent un tableau de bord à jour. Tout seul.',
  sound: 'Sound design « data » : clics, ticks rapides pendant la dispersion, aspiration (reverse whoosh) à la convergence, accord résolu à l’apparition du dashboard.',
  scenes: [
  S(3.6, 'dark', L => bg('grid') + logo() + title({ k: 'Données · Automatisation', lines: L === 'li' ? ['Vos données', 'sont partout.'] : ['Tes données', 'sont partout.'], size: 'xl' }) + A(`<div class="vs2">${L === 'li' ? 'Sauf là où vous en avez besoin.' : 'Sauf là où tu en as besoin.'}</div>`, { d: 1 }), { vis: 'Navy, accroche.', mv: 'Masque montant puis sous-titre.' }),
  S(9, 'dark', L => {
    const files = [['Ventes.xlsx', 12, 18], ['Stock_v3.xlsx', 58, 12], ['CRM', 22, 40], ['Compta', 66, 36], ['Export_marketplace.csv', 14, 64], ['Factures.pdf', 60, 62], ['Planning', 34, 82], ['Emails', 70, 84]];
    const css = files.map(([, x, y], i) => `@keyframes cv${i}{0%{left:${x}%;top:${y}%;opacity:1;transform:translate(-50%,-50%) rotate(${(i % 3 - 1) * 6}deg)}100%{left:50%;top:50%;opacity:0;transform:translate(-50%,-50%) scale(.4)}}`).join('');
    return `<style>${css}</style><div style="position:absolute;inset:0">${files.map(([t, x, y], i) => `<div class="a" style="position:absolute;left:${x}%;top:${y}%;transform:translate(-50%,-50%);--an:pop;--d:${.2 + i * .25}s"><div class="a" style="--an:cv${i};--d:${3.6 + i * .08}s;--du:1s;position:relative"><div class="vnode" style="font-size:28px;padding:18px 24px;transform:translate(-50%,-50%) rotate(${(i % 3 - 1) * 6}deg)"><div class="ic" style="width:46px;height:46px">${I[i % 2 ? 'doc' : 'db']}</div>${t}</div></div></div>`).join('')}</div>
    <div style="position:relative;z-index:3">${A(`<div class="mk" style="zoom:.95">${mock({ type: 'dash', h: 720, title: 'Vue unifiée', kpis: ['Ventes', 'Stock', 'Marge'], id: 'c2' })}</div>`, { an: 'blurin', d: 4.8, du: 1 })}</div>` + tag(L);
  }, { vis: 'Fichiers et outils éparpillés (tableurs, CRM, exports), puis convergence vers un dashboard unifié (données fictives).', mv: 'Pop des fichiers en cascade, aspiration vers le centre, apparition flou → net du dashboard.' }),
  S(4, 'light', L => title({ lines: ['Un tableau de bord.', 'À jour.', '<span class="g">Tout seul.</span>'], size: 'xl', step: .45 }), { vis: 'Lavande, punchline.', mv: 'Trois temps.' }),
  endCard({ ig: 'Parlons de ton projet', li: 'Parlons de votre projet' }),
]},
/* --------------------------------------------------------------- A02 */
A02: { vo: 'Trois chiffres à comprendre avant d’augmenter un budget pub. Le ROAS : ce que rapporte un euro investi. Le CPA : ce que coûte une vente. Le taux de conversion : la part de visiteurs qui passent à l’action. Pilotez, ne pariez pas.',
  sound: 'Beat minimal type « data », un impact par KPI, barres accompagnées d’un arpège montant.',
  scenes: [
  S(3.8, 'light', L => logo(false) + title({ k: 'Acquisition · Pédagogie', lines: ['3 chiffres', 'à comprendre avant', 'de <span class="g">booster</span> une pub.'], size: 'md' }), { vis: 'Lavande, accroche.', mv: 'Masque montant.' }),
  ...[['01', 'ROAS', 'Ce que rapporte 1 € investi en publicité.', 'Return On Ad Spend'], ['02', 'CPA', 'Ce que coûte une vente ou un contact.', 'Coût par acquisition'], ['03', 'Conversion', 'La part de visiteurs qui passent à l’action.', 'Taux de conversion']].map(([n, k, d, full], j) =>
    S(5.2, 'dark', L => bg('grid') + A(`<div class="vk">${n} / 03 · ${full}</div>`, { an: 'fade' }) + A(`<div class="vt xl"><span class="g">${k}</span></div>`, { an: 'pop', d: .2 }) + A(`<div class="vs2" style="font-size:46px;color:#fff">${d}</div>`, { d: .8 }) +
      `<div class="bars" style="height:300px;margin-top:70px">${[30, 44, 38, 56, 50, 68, 62, 80].map((h, i) => `<i class="a ${i > 4 ? 'on' : ''}" style="height:${h}%;transform-origin:bottom;--an:barup;--d:${1.2 + i * .12}s;--du:.6s;${i > 4 ? '' : 'background:rgba(185,166,255,.18)'}"></i>`).join('')}</div>` + A(`<div class="mono sm" style="color:rgba(255,255,255,.45);margin-top:22px">Données fictives</div>`, { an: 'fade', d: 2.2 }),
      { vis: `KPI « ${k} » en XL dégradé, définition, histogramme (données fictives).`, mv: 'Pop du sigle, barres qui montent en cascade.' })),
  S(4.2, 'light', L => title({ lines: L === 'li' ? ['Ensemble, rapportés', 'à vos marges.', '<span class="g">Pilotez</span>, ne pariez pas.'] : ['Ensemble, rapportés', 'à tes marges.', '<span class="g">Pilote</span>, ne parie pas.'], size: 'md', step: .4 }), { vis: 'Lavande, conclusion.', mv: 'Masque montant.' }),
  endCard({ ig: 'Parlons de tes campagnes', li: 'Échangeons sur vos campagnes' }),
]},
/* --------------------------------------------------------------- B02 */
B02: { vo: 'Votre identité digitale parle avant vous. Un symbole, une palette, une typographie, des règles. Et les mêmes codes, partout.',
  sound: 'Électro élégante, tempo moyen. « Clic » de construction à chaque élément graphique, accord ouvert sur les déclinaisons.',
  scenes: [
  S(3.8, 'dark', L => bg('grid') + logo() + title({ k: 'Branding', lines: L === 'li' ? ['Votre identité', 'digitale parle', '<span class="g">avant vous.</span>'] : ['Ton identité', 'digitale parle', '<span class="g">avant toi.</span>'], size: 'xl' }), { vis: 'Navy, accroche.', mv: 'Masque montant.' }),
  S(9, 'light', L => `<div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:28px">
     ${A(`<div class="card" style="grid-column:1/3;display:flex;align-items:center;gap:30px;padding:44px"><div style="width:140px;height:140px;border-radius:36px;background:var(--navy);display:grid;place-items:center"><div class="a" style="--an:spin;--du:1.2s;--d:.6s;width:84px;height:84px;border-radius:50%;border:14px solid #fff;border-right-color:transparent"></div></div><div><div class="mono sm" style="color:var(--muted)">01 · Symbole</div><div style="font:800 64px/1 var(--f-d);margin-top:12px">Votre marque</div></div></div>`, { an: 'up', d: .2 })}
     ${A(`<div class="card" style="padding:40px"><div class="mono sm" style="color:var(--muted)">02 · Palette</div><div style="display:flex;gap:12px;margin-top:22px">${['#12152B', '#315CFF', '#7C3AED', '#F2EEFF'].map((c, i) => `<div class="a" style="--an:pop;--d:${2 + i * .2}s;flex:1;height:130px;border-radius:16px;background:${c};border:2px solid var(--line)"></div>`).join('')}</div></div>`, { an: 'up', d: 1.6 })}
     ${A(`<div class="card" style="padding:40px"><div class="mono sm" style="color:var(--muted)">03 · Typographie</div><div class="a" style="--an:blurin;--d:3.4s;font:800 150px/1 var(--f-d);margin-top:10px">Aa</div></div>`, { an: 'up', d: 3 })}
     ${A(`<div class="card" style="grid-column:1/3;padding:40px"><div class="mono sm" style="color:var(--muted)">04 · Règles d’usage</div><div style="display:flex;gap:14px;margin-top:22px">${['Marges', 'Grille', 'Contrastes', 'Tons'].map((t, i) => `<span class="a chip" style="--an:pop;--d:${4.6 + i * .2}s;font-size:24px;padding:14px 20px">${t}</span>`).join('')}</div></div>`, { an: 'up', d: 4.2 })}</div>` + tagL(),
    { vis: 'Planche d’identité d’une marque fictive qui se construit : symbole, palette, typographie, règles.', mv: 'Cartes montées en cascade, échantillons en pop, « Aa » flou → net.' }),
  S(6, 'dark', L => A(`<div class="vk">Les mêmes codes, partout</div>`, { an: 'fade' }) + `<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">${[['Site', 'var(--lavender)', 'var(--ink)'], ['Réseaux', 'var(--grad)', '#fff'], ['Packaging', '#fff', 'var(--ink)'], ['Print', 'var(--navy2)', '#fff']].map(([t, b, c], i) => A(`<div style="height:300px;border-radius:28px;background:${b};color:${c};border:2px solid var(--line-d);display:flex;flex-direction:column;justify-content:space-between;padding:30px"><div style="width:70px;height:70px;border-radius:50%;border:12px solid currentColor;border-right-color:transparent"></div><div style="font:800 44px var(--f-d)">${t}</div></div>`, { an: 'pop', d: .3 + i * .35 })).join('')}</div>` + tag(L),
    { vis: 'Déclinaisons de la marque fictive : site, réseaux, packaging, print.', mv: 'Tuiles en pop successif (0,35 s).' }),
  S(3.8, 'light', L => title({ lines: ['Reconnue', 'en une <span class="g">seconde.</span>', 'Partout.'], size: 'xl', step: .4 }), { vis: 'Lavande, punchline.', mv: 'Trois temps.' }),
  endCard({ ig: 'Construisons ta marque', li: 'Construisons votre marque' }),
]},
/* --------------------------------------------------------------- S03 */
S03: { vo: 'Et si nous transformions votre idée en logiciel ? D’abord, on la challenge. Ensuite, on la rend concrète. Enfin, on la développe, on la déploie et on la fait évoluer.',
  sound: 'Montée progressive en trois paliers (un par étape), son de crayon sur l’idée, clics UI sur la maquette, impact sur le logiciel.',
  scenes: [
  S(3.8, 'dark', L => bg('grid') + logo() + title({ k: 'SaaS · Sur mesure', lines: L === 'li' ? ['Et si nous', 'transformions votre', 'idée en <span class="g">logiciel</span> ?'] : ['Et si on', 'transformait ton', 'idée en <span class="g">logiciel</span> ?'], size: 'md' }), { vis: 'Navy, accroche.', mv: 'Masque montant.' }),
  S(5, 'light', L => A(`<div class="vk">01 · L’idée</div>`, { an: 'fade' }) + A(`<div style="background:#FFF8D6;color:var(--ink);padding:70px 60px;border-radius:10px;transform:rotate(-2.5deg);box-shadow:0 30px 70px rgba(18,21,43,.18);font:700 64px/1.15 var(--f-d)">« Suivre mes commandes fournisseurs <span class="uline a" style="--an:hl;--d:1.6s;--du:.8s">sans tableur</span>. »</div>`, { an: 'pop', d: .3 }) + A(`<div class="vs2">On la challenge : quel problème, pour qui, quelle valeur.</div>`, { d: 1.6 }),
    { vis: 'Note autocollante avec une idée de logiciel.', mv: 'Pop légèrement incliné, surlignage magenta qui se trace.' }),
  S(5, 'white', L => A(`<div class="vk">02 · La maquette</div>`, { an: 'fade' }) + A(`<div class="browser" style="box-shadow:none"><div class="bar"><i></i><i></i><i></i></div><div class="vp" style="display:grid;grid-template-columns:180px 1fr;gap:24px;height:620px">
      <div style="display:flex;flex-direction:column;gap:16px">${'<div class="sk a" style="height:22px;--an:wipe;--d:.8s"></div>'.repeat(6)}</div>
      <div style="display:flex;flex-direction:column;gap:20px"><div class="sk a" style="height:60px;width:60%;--an:wipe;--d:1.1s"></div><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px">${'<div class="sk a" style="height:120px;--an:pop;--d:1.4s;border:3px dashed #CFCBE2;background:transparent"></div>'.repeat(3)}</div><div class="sk a" style="flex:1;--an:wipe;--d:1.8s;border:3px dashed #CFCBE2;background:transparent"></div></div></div></div>`, { an: 'up', d: .2 }) + A(`<div class="vs2">On la rend concrète : parcours, écrans, priorités.</div>`, { d: 2.2 }),
    { vis: 'Wireframe en niveaux de gris dans un navigateur.', mv: 'Blocs tracés par balayage, cartes en pop.' }),
  S(6, 'dark', L => A(`<div class="vk">03 · Le logiciel</div>`, { an: 'fade' }) + A(`<div class="mk">${mock({ type: 'dash', h: 760, title: 'Commandes fournisseurs', kpis: ['En cours', 'Expédiées', 'Retards'], id: 's3' })}</div>`, { an: 'blurin', d: .2, du: 1 }) + A(`<div class="vs2">On développe, on déploie, on fait évoluer.</div>`, { d: 1.6 }) + tag(L),
    { vis: 'Interface SaaS complète (concept, données fictives).', mv: 'Morphing flou → net depuis la maquette.' }),
  S(3.4, 'light', L => title({ lines: ['De l’idée', 'à la <span class="g">solution.</span>'], size: 'xl', step: .4 }), { vis: 'Lavande, punchline.', mv: 'Deux temps.' }),
  endCard({ ig: 'Transformons ton idée', li: 'Transformons votre idée en solution' }),
]},
/* --------------------------------------------------------------- F02 */
F02: { vo: 'Un seul interlocuteur, de l’idée au lancement. Comprendre. Concevoir. Produire. Développer. Pas de relais entre quatre prestataires. Une équipe, une vision.',
  sound: 'Rythme confiant, 4 impacts synchronisés sur les étapes. Final ouvert, chaleureux (clôture de série).',
  scenes: [
  S(3.8, 'dark', L => bg('grid') + logo() + title({ k: 'Notre méthode', lines: ['Un seul interlocuteur.', 'De l’idée', 'au <span class="g">lancement.</span>'], size: 'md' }), { vis: 'Navy, accroche.', mv: 'Masque montant.' }),
  S(11, 'white', L => `<div style="position:relative;padding-left:70px">
      <div class="a" style="position:absolute;left:22px;top:20px;bottom:20px;width:6px;border-radius:6px;background:var(--grad);transform-origin:top;--an:barup;--d:.3s;--du:7.5s"></div>
      ${[['01', 'Comprendre', { ig: 'Ton activité, tes enjeux, tes contraintes.', li: 'Votre activité, vos enjeux, vos contraintes.' }], ['02', 'Concevoir', 'La bonne solution : technologique, marketing, ou les deux.'], ['03', 'Produire', 'Développer, créer, intégrer.'], ['04', 'Développer', 'Mesurer, optimiser, faire évoluer.']].map(([n, t, d], i) =>
        A(`<div style="position:relative;padding:34px 0"><div style="position:absolute;left:-62px;top:44px;width:30px;height:30px;border-radius:50%;background:#fff;border:6px solid var(--violet)"></div><div class="mono" style="color:var(--violet)">${n}</div><div style="font:800 76px/1 var(--f-d);letter-spacing:-.03em;margin-top:12px">${t}</div><div class="body" style="margin-top:12px">${tx(d, L)}</div></div>`, { an: 'left', d: .4 + i * 1.9 })).join('')}</div>`,
    { vis: 'Timeline verticale en 4 étapes, filet dégradé qui progresse.', mv: 'Le filet se trace sur 7,5 s, chaque étape glisse à son arrivée (1,9 s).' }),
  S(4.2, 'light', L => title({ lines: [`<span style="position:relative;display:inline-block">Pas de relais entre<br>4 prestataires.<span class="a" style="position:absolute;left:0;right:0;top:55%;height:10px;background:var(--magenta);transform-origin:left;--an:strike;--d:1.2s;--du:.5s"></span></span>`], size: 'md' }) + A(`<div class="vt md" style="margin-top:40px">Une équipe. <span class="g">Une vision.</span></div>`, { d: 1.8 }),
    { vis: 'Lavande, phrase barrée puis promesse.', mv: 'Trait magenta qui barre, apparition de la promesse.' }),
  endCard({ ig: 'Construisons ta prochaine solution', li: 'Construisons votre prochaine solution' }, 'Merci d’avoir suivi cette première série.'),
]},
};

export function videoHTML(key, L, fmtK) {
  const v = VIDEOS[key]; let t = 0;
  const secs = v.scenes.map((s, i) => { const st = t; t += s.d; const last = i === v.scenes.length - 1;
    return `<section class="sc ${s.cls}" style="--s:${st}s;--e:${t}s">${s.html(L, fmtK)}</section>`; }).join('');
  return { html: `<div class="vid ${fmtK}">${secs}</div>`, dur: t };
}
export function storyboard(key, L = 'ig') {
  const v = VIDEOS[key]; let t = 0;
  return v.scenes.map((s, i) => { const st = t; t += s.d;
    const txt = s.html(L, 'v916').replace(/<style>[\s\S]*?<\/style>/g, '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').replace(/Exemple illustratif/g, '').trim();
    return { n: i + 1, from: st, to: t, text: txt, ...s.sb }; });
}
