// Construit la galerie web de prévisualisation (out/gallery) à partir des données source.
import fs from 'node:fs';
import { execSync } from 'node:child_process';
import { CONTENTS } from '../src/contents.mjs';
import { VIDEOS, storyboard } from '../src/videos.mjs';
const G = 'out/gallery'; fs.mkdirSync(`${G}/m`, { recursive: true });
const man = JSON.parse(fs.readFileSync('out/manifest-slides.json'));
const sh = c => execSync(c, { stdio: 'pipe' });
const items = [];
for (const c of CONTENTS) {
  const it = { ...c }; delete it.slides; delete it.static; delete it.video;
  it.media = { ig: [], li: [] };
  if (man[c.id]) {
    for (const L of ['ig', 'li']) man[c.id][L].forEach((f, k) => {
      const o = `m/${c.id}_${L}_${k + 1}.jpg`;
      if (!fs.existsSync(`${G}/${o}`)) sh(`ffmpeg -loglevel error -y -i "${f}" -vf scale=720:-1 -q:v 4 ${G}/${o}`);
      it.media[L].push(o);
    });
    
  }
  if (c.video) {
    const V = VIDEOS[c.video];
    it.vo = V.vo; it.sound = V.sound;
    it.sb = { ig: storyboard(c.video, 'ig'), li: storyboard(c.video, 'li') };
    it.dur = it.sb.ig.at(-1).to;
    for (const [L, f, w] of [['ig', 'v916', 540], ['li', 'v45', 540]]) {
      const src = `out/video/${c.video}_${L}_${f}.mp4`;
      if (!fs.existsSync(src)) { console.warn('manque', src); continue; }
      const o = `m/${c.id}_${L}.mp4`, cv = `m/${c.id}_${L}_cover.jpg`;
      if (!fs.existsSync(`${G}/${o}`)) sh(`ffmpeg -loglevel error -y -i ${src} -vf scale=${w}:-2 -c:v libx264 -preset veryfast -crf 26 -pix_fmt yuv420p -movflags +faststart -an ${G}/${o}`);
      sh(`ffmpeg -loglevel error -y -i ${src.replace('.mp4', '_cover.png')} -vf scale=720:-1 -q:v 4 ${G}/${cv}`);
      it.media[L] = { video: o, cover: cv };
    }
  }
  items.push(it);
}
const tpl = fs.readFileSync('scripts/gallery.html', 'utf8');
fs.writeFileSync(`${G}/index.html`, tpl.replace('/*DATA*/', 'const DATA=' + JSON.stringify(items).replace(/</g, '\\u003c') + ';'));
console.log('items', items.length, 'files', fs.readdirSync(`${G}/m`).length);
