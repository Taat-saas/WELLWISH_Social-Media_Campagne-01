/* Assemble UN SEUL contenu, sans toucher au reste de la livraison.
   `scripts/package.mjs` efface le dossier complet avant de le reconstruire :
   l'utiliser pour un ajout aurait supprimé les 30 contenus déjà validés. */
import fs from 'node:fs';
import { CONTENTS } from '../src/contents.mjs';
const id = process.argv[2];
const R = '/mnt/user-data/outputs/WW-ajout';
const c = CONTENTS.find(x => x.id === id);
if (!c) throw new Error('contenu inconnu ' + id);
const man = JSON.parse(fs.readFileSync('out/manifest-slides.json'));
const cp = (a, b) => { fs.mkdirSync(b.replace(/\/[^/]+$/, ''), { recursive: true }); fs.copyFileSync(a, b); };
/* Préfixé par la date : les dossiers se classent dans l'ordre de publication. */
const slug = x => `${x.date}_${x.id}_${x.title.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 48)}`;
const d = `${R}/${slug(c)}`;
fs.rmSync(d, { recursive: true, force: true });
man[c.id].ig.forEach(f => cp(f, `${d}/Instagram/${f.split('/').pop()}`));
man[c.id].li.forEach(f => cp(f, `${d}/LinkedIn/${f.split('/').pop()}`));
if (man[c.id].pdf) cp(man[c.id].pdf, `${d}/LinkedIn/${c.id}_LinkedIn_document.pdf`);
const t = `${c.id} — ${c.title}\n${'='.repeat(60)}\nPublication : semaine ${c.week} · ${c.date} · Instagram ${c.hours.ig} · LinkedIn ${c.hours.li}\nFormat : ${c.format} · Thématique : ${c.theme} · Pilier : ${c.pillar}\nObjectif : ${c.objective}\nDirection artistique : ${c.da}\n\n--- INSTAGRAM ---\nAccroche : ${c.hook.ig}\nCTA : ${c.cta.ig}\n\n${c.captionIG}\n\n${c.tags.ig}\n\n--- LINKEDIN ---\nAccroche : ${c.hook.li}\nCTA : ${c.cta.li}\n\n${c.textLI}\n\n${c.tags.li}\n`;
fs.writeFileSync(`${d}/${c.id}_textes.txt`, t);
console.log(d, '·', fs.readdirSync(`${d}/Instagram`).length, 'PNG IG');
