import { chromium } from 'playwright';
import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { videoHTML, VIDEOS } from '../src/videos.mjs';
const FPS = +process.env.FPS || 30;
const jobs = process.argv.slice(2); // KEY:lang:fmt  ex. P01:ig:v916
const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome' });
fs.mkdirSync('out/video', { recursive: true });
async function run(job) {
  const [key, L, f] = job.split(':'); const H = f === 'v916' ? 1920 : 1350;
  const { html, dur } = videoHTML(key, L, f);
  const file = `src/_v_${key}_${L}_${f}.html`;
  fs.writeFileSync(file, `<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="ds.css"><link rel="stylesheet" href="motion.css"><style>html,body{margin:0;width:1080px;height:${H}px;overflow:hidden;background:#12152B}</style></head><body>${html}</body></html>`);
  const p = await b.newPage({ viewport: { width: 1080, height: H } });
  await p.goto('file://' + process.cwd() + '/' + file); await p.evaluate(() => document.fonts.ready);
  const out = `out/video/${key}_${L}_${f}.mp4`;
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(FPS), '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', out]);
  const N = Math.round(dur * FPS);
  for (let i = 0; i < N; i++) {
    await p.evaluate(t => document.getAnimations().forEach(a => { a.pause(); a.currentTime = t; }), i * 1000 / FPS);
    const buf = await p.screenshot({ type: 'jpeg', quality: 92 });
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
  }
  ff.stdin.end(); await new Promise(r => ff.on('close', r));
  // couverture : fin de la scène d'accroche
  const tc = (VIDEOS[key].scenes[0].d - .25) * 1000;
  await p.evaluate(t => document.getAnimations().forEach(a => { a.pause(); a.currentTime = t; }), tc);
  await p.screenshot({ path: `out/video/${key}_${L}_${f}_cover.png` });
  await p.close(); console.log('ok', job, dur.toFixed(1) + 's');
}
const conc = +process.env.CONC || 3; const q = [...jobs];
await Promise.all(Array.from({ length: conc }, async () => { while (q.length) await run(q.shift()); }));
await b.close();
