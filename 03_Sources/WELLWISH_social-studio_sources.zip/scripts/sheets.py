import json,sys,os
from PIL import Image
m=json.load(open('out/manifest-slides.json'))
os.makedirs('out/qa',exist_ok=True)
lang=sys.argv[1] if len(sys.argv)>1 else 'ig'
for k,v in m.items():
    fs=v[lang]; n=len(fs); cols=4; rows=(n+cols-1)//cols
    W=Image.new('RGB',(cols*540,rows*675),'black')
    for i,f in enumerate(fs): W.paste(Image.open(f).convert('RGB').resize((540,675)),((i%cols)*540,(i//cols)*675))
    W.save(f'out/qa/{k}_{lang}.jpg',quality=80)
