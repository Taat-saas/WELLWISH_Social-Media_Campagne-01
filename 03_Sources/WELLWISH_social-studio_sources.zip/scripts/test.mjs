import { chromium } from 'playwright';
import fs from 'node:fs';
import { slide, page } from '../src/tpl.mjs';
const S = [
 {l:'cover',kicker:'Web · Conseil',title:'Ton site *travaille*-t-il vraiment pour toi ?',sub:'5 signaux à vérifier avant de dépenser un euro de plus en visibilité.'},
 {l:'point',num:'01',title:'Le visiteur comprend-il en 5 secondes ?',body:'Une promesse floue fait fuir. Ce que tu fais, pour qui, et l’étape suivante doivent être visibles sans défiler.',v:{type:'site-new',h:430},concept:true},
 {l:'vs',kicker:'Avant / Après',title:'Même trafic, autre *résultat*.',bad:{h:'Site vitrine figé',r:['Promesse floue','Aucun appel à l’action','Lent sur mobile']},good:{h:'Site qui travaille',r:['Promesse en une phrase','Un parcours vers le contact','Rapide et mesuré']}},
 {l:'cta',title:'Faisons de ton site un *levier*.',body:'Audit, refonte, optimisation : on part de tes objectifs.',cta:'Parlons de ton projet'},
 {l:'visual',kicker:'Pilotage',title:'Un tableau de bord, pas dix exports.',v:{type:'dash',h:620}},
 {l:'list',kicker:'Checklist',title:'Les 4 *fuites* les plus fréquentes',items:[{t:'Promesse floue',s:'Le visiteur ne sait pas ce que tu vends.'},{t:'Pas de CTA',s:'Aucune étape suivante.'},{t:'Lenteur mobile'},{t:'Aucune mesure'}]},
];
const b = await chromium.launch({executablePath:'/usr/bin/google-chrome'});
const p = await b.newPage({viewport:{width:1080,height:1350}});
fs.mkdirSync('out/test',{recursive:true});
for (const [k,s] of S.entries()){ fs.writeFileSync('src/_t.html', page(slide(s,{lang:'ig',i:k+1,n:6}))); await p.goto('file://'+process.cwd()+'/src/_t.html'); await p.evaluate(()=>document.fonts.ready); await p.screenshot({path:`out/test/${k}.png`}); }
await b.close();
