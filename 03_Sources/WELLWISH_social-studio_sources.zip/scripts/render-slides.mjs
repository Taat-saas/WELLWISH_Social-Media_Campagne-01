import { chromium } from 'playwright';
import fs from 'node:fs';
import { CONTENTS } from '../src/contents.mjs';
import { slide, page } from '../src/tpl.mjs';
const only = process.argv[2]?.split(',');
const OUT = 'out/exports';
const slug = c => `${c.id}_${c.title.normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^A-Za-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,48)}`;
const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome' });
const p = await b.newPage({ viewport: { width: 1080, height: 1350 } });
const manifest = {};
for (const c of CONTENTS) {
  if (!c.slides && !c.static) continue;
  if (only && !only.includes(c.id)) continue;
  const dir = `${OUT}/${slug(c)}`; fs.mkdirSync(dir, { recursive: true });
  manifest[c.id] = { dir, ig: [], li: [] };
  for (const lang of ['ig', 'li']) {
    const list = c.slides || [c.static];
    const htmls = list.map((s, k) => slide(s, { lang, i: c.slides ? k + 1 : undefined, n: c.slides ? list.length : undefined }));
    for (const [k, h] of htmls.entries()) {
      fs.writeFileSync('src/_r.html', page(h));
      await p.goto('file://' + process.cwd() + '/src/_r.html'); await p.evaluate(() => document.fonts.ready);
      const f = `${dir}/${c.id}_${lang === 'ig' ? 'Instagram' : 'LinkedIn'}_${String(k + 1).padStart(2, '0')}.png`;
      await p.screenshot({ path: f }); manifest[c.id][lang].push(f);
    }
    if (lang === 'li' && c.slides) {
      const doc = `<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="ds.css"><style>@page{size:1080px 1350px;margin:0}html,body{background:#fff}.frame{page-break-after:always;break-after:page}</style></head><body>${htmls.join('')}</body></html>`;
      fs.writeFileSync('src/_r.html', doc);
      await p.goto('file://' + process.cwd() + '/src/_r.html'); await p.evaluate(() => document.fonts.ready);
      const pdf = `${dir}/${c.id}_LinkedIn_document.pdf`;
      await p.pdf({ path: pdf, width: '1080px', height: '1350px', printBackground: true, pageRanges: `1-${htmls.length}` });
      manifest[c.id].pdf = pdf;
    }
  }
  console.log(c.id, manifest[c.id].ig.length);
}
const prev = fs.existsSync('out/manifest-slides.json') ? JSON.parse(fs.readFileSync('out/manifest-slides.json')) : {};
fs.writeFileSync('out/manifest-slides.json', JSON.stringify({ ...prev, ...manifest }, null, 1));
await b.close();
