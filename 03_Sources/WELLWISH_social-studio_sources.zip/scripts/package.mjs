// Assemble le dossier de livraison : exports prêts à publier + textes + storyboards + sources.
import fs from 'node:fs';
import { execSync } from 'node:child_process';
import { CONTENTS } from '../src/contents.mjs';
import { VIDEOS, storyboard } from '../src/videos.mjs';
const R = '/mnt/user-data/outputs/WELLWISH_Social-Media_Campagne-01';
fs.rmSync(R, { recursive: true, force: true }); fs.mkdirSync(R, { recursive: true });
const man = JSON.parse(fs.readFileSync('out/manifest-slides.json'));
const cp = (a, b) => { fs.mkdirSync(b.replace(/\/[^/]+$/, ''), { recursive: true }); fs.copyFileSync(a, b); };
/* Préfixé par la date : les dossiers se classent dans l'ordre de publication. */
const slug = c => `${c.date}_${c.id}_${c.title.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 48)}`;
for (const c of CONTENTS) {
  const d = `${R}/02_Contenus/${slug(c)}`;
  if (man[c.id]) {
    man[c.id].ig.forEach(f => cp(f, `${d}/Instagram/${f.split('/').pop()}`));
    if (man[c.id].pdf) cp(man[c.id].pdf, `${d}/LinkedIn/${c.id}_LinkedIn_document.pdf`);
    else man[c.id].li.forEach(f => cp(f, `${d}/LinkedIn/${f.split('/').pop()}`));
  }
  if (c.video) {
    cp(`out/video/${c.video}_ig_v916.mp4`, `${d}/Instagram/${c.id}_Reel_1080x1920.mp4`);
    cp(`out/video/${c.video}_ig_v916_cover.png`, `${d}/Instagram/${c.id}_Reel_couverture.png`);
    cp(`out/video/${c.video}_li_v45.mp4`, `${d}/LinkedIn/${c.id}_LinkedIn_1080x1350.mp4`);
  }
  let t = `${c.id} — ${c.title}\n${'='.repeat(60)}\nPublication : semaine ${c.week} · ${c.date} · Instagram ${c.hours.ig} · LinkedIn ${c.hours.li}\nFormat : ${c.format} · Thématique : ${c.theme} · Pilier : ${c.pillar}\nObjectif : ${c.objective}\nDirection artistique : ${c.da}\n\n--- INSTAGRAM ---\nAccroche : ${c.hook.ig}\nCTA : ${c.cta.ig}\n\n${c.captionIG}\n\n${c.tags.ig}\n\n--- LINKEDIN ---\nAccroche : ${c.hook.li}\nCTA : ${c.cta.li}\n\n${c.textLI}\n\n${c.tags.li}\n`;
  if (c.video) {
    const V = VIDEOS[c.video];
    t += `\n--- STORYBOARD (version Instagram) ---\n` + storyboard(c.video).map(r => `${r.from.toFixed(1)}–${r.to.toFixed(1)} s | Visuel : ${r.vis}\n            Texte : ${r.text}\n            Mouvement : ${r.mv}`).join('\n') + `\n\nVoix off (option) : ${V.vo}\nIndications sonores : ${V.sound}\nCouverture : dernière image de l'accroche (fichier _Reel_couverture.png).\n`;
  }
  fs.writeFileSync(`${d}/${c.id}_textes.txt`, t);
}
cp('out/WELLWISH_Calendrier-editorial_Campagne-01.xlsx', `${R}/01_Calendrier/WELLWISH_Calendrier-editorial_Campagne-01.xlsx`);
fs.mkdirSync(`${R}/03_Sources`, { recursive: true });
execSync(`cd /home/claude/ww && rm -f src/_*.html && zip -qr ${R}/03_Sources/WELLWISH_social-studio_sources.zip src scripts assets README-SOURCES.md package.json`);
console.log(execSync(`cd ${R} && find . -type f | wc -l && du -sh .`).toString());
